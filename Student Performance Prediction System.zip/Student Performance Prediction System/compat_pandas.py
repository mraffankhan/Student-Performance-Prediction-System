"""
compat_pandas.py - Resilient Pandas Compatibility Layer
Student Performance Prediction System

Provides standard pandas when available. If Windows Smart App Control (SAC)
or environment policy blocks compiled C-extension DLLs (such as pandas tslibs),
this module seamlessly falls back to a clean, pure-Python + NumPy DataFrame implementation.
"""

import sys
import csv
import json
import sqlite3
from datetime import datetime
from typing import List, Dict, Any, Optional, Union, Tuple
import numpy as np

_USE_REAL_PANDAS = False

try:
    import pandas as _pd
    # Test importing a key submodule that might be blocked by WDAC/SAC
    from pandas.core.dtypes.common import is_numeric_dtype
    _USE_REAL_PANDAS = True
    pd = _pd
except (ImportError, OSError):
    _USE_REAL_PANDAS = False


if not _USE_REAL_PANDAS:

    class Series:
        def __init__(self, data, name=None):
            self.name = name
            if isinstance(data, (list, tuple)):
                self._data = list(data)
            elif isinstance(data, np.ndarray):
                self._data = data.tolist()
            elif isinstance(data, Series):
                self._data = list(data._data)
            else:
                self._data = [data]

        def __len__(self):
            return len(self._data)

        def __iter__(self):
            return iter(self._data)

        def __getitem__(self, idx):
            if isinstance(idx, (list, np.ndarray, Series)):
                # Boolean mask or integer indexing
                if len(idx) > 0 and isinstance(idx[0], (bool, np.bool_)):
                    return Series([v for v, m in zip(self._data, idx) if m], name=self.name)
                return Series([self._data[i] for i in idx], name=self.name)
            return self._data[idx]

        @property
        def values(self):
            return np.array(self._data)

        def mean(self):
            nums = [float(x) for x in self._data if x is not None and not (isinstance(x, float) and np.isnan(x))]
            return float(np.mean(nums)) if nums else 0.0

        def sum(self):
            nums = [float(x) for x in self._data if x is not None and not (isinstance(x, float) and np.isnan(x))]
            return float(np.sum(nums)) if nums else 0.0

        def min(self):
            nums = [float(x) for x in self._data if x is not None]
            return min(nums) if nums else 0

        def max(self):
            nums = [float(x) for x in self._data if x is not None]
            return max(nums) if nums else 0

        def isin(self, values):
            val_set = set(values)
            return Series([x in val_set for x in self._data], name=self.name)

        def value_counts(self):
            counts = {}
            for item in self._data:
                counts[item] = counts.get(item, 0) + 1
            # Return dict or series-like mapping
            class ValueCounts(dict):
                def to_dict(self):
                    return dict(self)
            return ValueCounts(counts)

        def tolist(self):
            return list(self._data)

        def __repr__(self):
            return f"Series({self._data})"

        def __eq__(self, other):
            return Series([x == other for x in self._data], name=self.name)

        def __ne__(self, other):
            return Series([x != other for x in self._data], name=self.name)

        def __ge__(self, other):
            return Series([(x >= other) if x is not None else False for x in self._data], name=self.name)

        def __gt__(self, other):
            return Series([(x > other) if x is not None else False for x in self._data], name=self.name)

        def __le__(self, other):
            return Series([(x <= other) if x is not None else False for x in self._data], name=self.name)

        def __lt__(self, other):
            return Series([(x < other) if x is not None else False for x in self._data], name=self.name)


    class DataFrame:
        def __init__(self, data=None, columns=None):
            self._records = []
            self.columns = []

            if data is None:
                self._records = []
                self.columns = list(columns) if columns else []
            elif isinstance(data, list):
                if data and isinstance(data[0], dict):
                    self._records = [dict(r) for r in data]
                    self.columns = list(columns) if columns else list(data[0].keys())
                elif data and isinstance(data[0], (list, tuple)):
                    cols = list(columns) if columns else [f"col_{i}" for i in range(len(data[0]))]
                    self.columns = cols
                    self._records = [dict(zip(cols, row)) for row in data]
                else:
                    self._records = []
                    self.columns = list(columns) if columns else []
            elif isinstance(data, dict):
                # Dict of lists
                keys = list(data.keys())
                self.columns = list(columns) if columns else keys
                n_rows = len(data[keys[0]]) if keys else 0
                self._records = []
                for i in range(n_rows):
                    row = {k: data[k][i] for k in keys}
                    self._records.append(row)
            elif isinstance(data, DataFrame):
                self._records = [dict(r) for r in data._records]
                self.columns = list(data.columns)
            else:
                self._records = []
                self.columns = []

        @property
        def empty(self) -> bool:
            return len(self._records) == 0

        @property
        def shape(self) -> Tuple[int, int]:
            return (len(self._records), len(self.columns))

        def __len__(self):
            return len(self._records)

        def __getitem__(self, item):
            if isinstance(item, str):
                vals = [r.get(item) for r in self._records]
                return Series(vals, name=item)
            elif isinstance(item, list) and all(isinstance(x, str) for x in item):
                # Sub-dataframe with selected columns
                sub_records = [{k: r.get(k) for k in item} for r in self._records]
                return DataFrame(sub_records, columns=item)
            elif isinstance(item, (Series, list, np.ndarray)):
                # Boolean filtering
                mask = list(item)
                filtered = [r for r, m in zip(self._records, mask) if m]
                return DataFrame(filtered, columns=self.columns)
            raise KeyError(f"Invalid column or slice: {item}")

        def __setitem__(self, key, value):
            if key not in self.columns:
                self.columns.append(key)
            if isinstance(value, (list, tuple, Series, np.ndarray)):
                for r, v in zip(self._records, value):
                    r[key] = v
            else:
                for r in self._records:
                    r[key] = value

        def copy(self):
            return DataFrame([dict(r) for r in self._records], columns=list(self.columns))

        def head(self, n=5):
            return DataFrame(self._records[:n], columns=self.columns)

        def tail(self, n=5):
            return DataFrame(self._records[-n:], columns=self.columns)

        def iterrows(self):
            for i, r in enumerate(self._records):
                yield i, r

        def to_dict(self, orient="records"):
            if orient == "records":
                return [dict(r) for r in self._records]
            elif orient == "list":
                return {c: [r.get(c) for r in self._records] for c in self.columns}
            return [dict(r) for r in self._records]

        def to_csv(self, path=None, index=False):
            if not self.columns and self._records:
                self.columns = list(self._records[0].keys())

            if path is None:
                import io
                out = io.StringIO()
                writer = csv.DictWriter(out, fieldnames=self.columns)
                writer.writeheader()
                for r in self._records:
                    writer.writerow({c: r.get(c, "") for c in self.columns})
                return out.getvalue()
            else:
                with open(path, "w", newline="", encoding="utf-8") as f:
                    writer = csv.DictWriter(f, fieldnames=self.columns)
                    writer.writeheader()
                    for r in self._records:
                        writer.writerow({c: r.get(c, "") for c in self.columns})

        def dropna(self, subset=None):
            cols = subset if subset else self.columns
            valid = []
            for r in self._records:
                keep = True
                for c in cols:
                    val = r.get(c)
                    if val is None or (isinstance(val, float) and np.isnan(val)) or val == "":
                        keep = False
                        break
                if keep:
                    valid.append(r)
            return DataFrame(valid, columns=self.columns)

        @property
        def iloc(self):
            class ILoc:
                def __init__(self, parent):
                    self.parent = parent
                def __getitem__(self, idx):
                    if isinstance(idx, int):
                        return self.parent._records[idx]
                    elif isinstance(idx, slice):
                        return DataFrame(self.parent._records[idx], columns=self.parent.columns)
                    return self.parent._records[idx]
            return ILoc(self)

        def __repr__(self):
            return f"DataFrame(rows={len(self._records)}, cols={self.columns})"


    class Timestamp:
        @classmethod
        def now(cls):
            class _Now:
                def strftime(self, fmt):
                    return datetime.now().strftime(fmt)
                def __str__(self):
                    return datetime.now().strftime("%Y-%m-%d %H:%M:%S")
            return _Now()


    def read_csv(path_or_buf) -> DataFrame:
        records = []
        with open(path_or_buf, mode="r", encoding="utf-8") as f:
            reader = csv.DictReader(f)
            columns = reader.fieldnames or []
            for row in reader:
                records.append(row)
        return DataFrame(records, columns=columns)


    def read_sql_query(sql, con, params=None) -> DataFrame:
        cursor = con.cursor()
        cursor.execute(sql, params or [])
        rows = cursor.fetchall()
        cols = [d[0] for d in cursor.description] if cursor.description else []
        records = [dict(zip(cols, row)) for row in rows]
        return DataFrame(records, columns=cols)


    def to_numeric(arg, errors="coerce"):
        if isinstance(arg, Series):
            res = []
            for x in arg:
                try:
                    res.append(float(x))
                except (ValueError, TypeError):
                    res.append(np.nan)
            return Series(res, name=arg.name)
        elif isinstance(arg, (list, tuple)):
            res = []
            for x in arg:
                try:
                    res.append(float(x))
                except (ValueError, TypeError):
                    res.append(np.nan)
            return np.array(res)
        try:
            return float(arg)
        except Exception:
            return np.nan


    # Export namespace
    class _PandasNamespace:
        DataFrame = DataFrame
        Series = Series
        read_csv = staticmethod(read_csv)
        read_sql_query = staticmethod(read_sql_query)
        to_numeric = staticmethod(to_numeric)
        Timestamp = Timestamp

    pd = _PandasNamespace()

