"""
database.py - SQLite Database Management Module
Student Performance Prediction System

Provides database initialization, schema management, CRUD operations for students
and predictions, and introspection helpers for the integrated Database Viewer.
"""

import sqlite3
import os
from datetime import datetime
from typing import List, Dict, Any, Optional, Tuple
import compat_pandas as pd

# Local database file path
BASE_DIR = os.path.dirname(os.path.abspath(__file__))
DB_NAME = "student_performance.db"
DB_PATH = os.path.join(BASE_DIR, DB_NAME)


def get_connection() -> sqlite3.Connection:
    """Creates and returns a connection to the SQLite database with row factory."""
    conn = sqlite3.connect(DB_PATH)
    conn.row_factory = sqlite3.Row
    conn.execute("PRAGMA foreign_keys = ON;")
    return conn


def init_db() -> None:
    """Initializes the database schema if tables do not exist."""
    with get_connection() as conn:
        cursor = conn.cursor()

        # Students table
        cursor.execute("""
            CREATE TABLE IF NOT EXISTS students (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                student_id TEXT UNIQUE NOT NULL,
                student_name TEXT NOT NULL,
                age INTEGER NOT NULL,
                gender TEXT DEFAULT 'Unspecified',
                semester TEXT NOT NULL,
                attendance REAL NOT NULL,
                previous_marks REAL NOT NULL,
                study_hours REAL NOT NULL,
                assignment_completion REAL NOT NULL,
                internal_marks REAL NOT NULL,
                extracurricular TEXT DEFAULT 'No',
                created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
            );
        """)

        # Predictions table
        cursor.execute("""
            CREATE TABLE IF NOT EXISTS predictions (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                student_id TEXT NOT NULL,
                student_name TEXT,
                predicted_marks REAL NOT NULL,
                performance_level TEXT NOT NULL,
                risk_level TEXT NOT NULL,
                prediction_date TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
                factors_summary TEXT,
                FOREIGN KEY (student_id) REFERENCES students(student_id) ON DELETE CASCADE
            );
        """)

        # Indexes for fast search
        cursor.execute("CREATE INDEX IF NOT EXISTS idx_students_id ON students(student_id);")
        cursor.execute("CREATE INDEX IF NOT EXISTS idx_predictions_sid ON predictions(student_id);")
        cursor.execute("CREATE INDEX IF NOT EXISTS idx_students_name ON students(student_name);")

        conn.commit()


def get_next_student_id() -> str:
    """Generates the next sequential student ID in the format STU-1001."""
    init_db()
    with get_connection() as conn:
        cursor = conn.cursor()
        cursor.execute("SELECT student_id FROM students WHERE student_id LIKE 'STU-%' ORDER BY id DESC LIMIT 1;")
        row = cursor.fetchone()
        if row and row["student_id"]:
            try:
                numeric_part = int(row["student_id"].replace("STU-", ""))
                return f"STU-{numeric_part + 1:04d}"
            except ValueError:
                pass
        
        cursor.execute("SELECT COUNT(*) as count FROM students;")
        count = cursor.fetchone()["count"]
        return f"STU-{1001 + count:04d}"


def add_student(data: Dict[str, Any]) -> str:
    """
    Inserts a new student record into the students table.
    Returns the student_id.
    """
    init_db()
    student_id = data.get("student_id") or get_next_student_id()
    
    with get_connection() as conn:
        cursor = conn.cursor()
        cursor.execute("""
            INSERT INTO students (
                student_id, student_name, age, gender, semester,
                attendance, previous_marks, study_hours,
                assignment_completion, internal_marks, extracurricular
            ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?);
        """, (
            student_id,
            str(data["student_name"]).strip(),
            int(data["age"]),
            data.get("gender", "Unspecified"),
            str(data["semester"]),
            float(data["attendance"]),
            float(data["previous_marks"]),
            float(data["study_hours"]),
            float(data["assignment_completion"]),
            float(data["internal_marks"]),
            data.get("extracurricular", "No")
        ))
        conn.commit()
    return student_id


def update_student(student_id: str, data: Dict[str, Any]) -> bool:
    """Updates an existing student's details in SQLite."""
    init_db()
    with get_connection() as conn:
        cursor = conn.cursor()
        cursor.execute("""
            UPDATE students SET
                student_name = ?,
                age = ?,
                gender = ?,
                semester = ?,
                attendance = ?,
                previous_marks = ?,
                study_hours = ?,
                assignment_completion = ?,
                internal_marks = ?,
                extracurricular = ?
            WHERE student_id = ?;
        """, (
            str(data["student_name"]).strip(),
            int(data["age"]),
            data.get("gender", "Unspecified"),
            str(data["semester"]),
            float(data["attendance"]),
            float(data["previous_marks"]),
            float(data["study_hours"]),
            float(data["assignment_completion"]),
            float(data["internal_marks"]),
            data.get("extracurricular", "No"),
            student_id
        ))
        updated = cursor.rowcount > 0

        # Also update name in predictions if present
        if updated:
            cursor.execute("""
                UPDATE predictions SET student_name = ? WHERE student_id = ?;
            """, (str(data["student_name"]).strip(), student_id))

        conn.commit()
    return updated


def delete_student(student_id: str) -> bool:
    """Deletes a student record and their associated predictions from SQLite."""
    init_db()
    with get_connection() as conn:
        cursor = conn.cursor()
        # Explicitly delete predictions first to maintain consistency
        cursor.execute("DELETE FROM predictions WHERE student_id = ?;", (student_id,))
        cursor.execute("DELETE FROM students WHERE student_id = ?;", (student_id,))
        deleted = cursor.rowcount > 0
        conn.commit()
    return deleted


def get_student_by_id(student_id: str) -> Optional[Dict[str, Any]]:
    """Retrieves a single student's dictionary by student_id."""
    init_db()
    with get_connection() as conn:
        cursor = conn.cursor()
        cursor.execute("SELECT * FROM students WHERE student_id = ?;", (student_id,))
        row = cursor.fetchone()
        if row:
            return dict(row)
    return None


def get_all_students(search: Optional[str] = None, semester: Optional[str] = None) -> pd.DataFrame:
    """Fetches students matching optional search query and semester filter."""
    init_db()
    query = "SELECT * FROM students WHERE 1=1"
    params = []

    if search:
        search_pattern = f"%{search.strip()}%"
        query += " AND (student_id LIKE ? OR student_name LIKE ?)"
        params.extend([search_pattern, search_pattern])

    if semester and semester != "All":
        query += " AND semester = ?"
        params.append(semester)

    query += " ORDER BY id DESC"

    with get_connection() as conn:
        df = pd.read_sql_query(query, conn, params=params)
    return df


def add_prediction(data: Dict[str, Any]) -> int:
    """Inserts a performance prediction result into the predictions table."""
    init_db()
    with get_connection() as conn:
        cursor = conn.cursor()
        cursor.execute("""
            INSERT INTO predictions (
                student_id, student_name, predicted_marks,
                performance_level, risk_level, prediction_date, factors_summary
            ) VALUES (?, ?, ?, ?, ?, ?, ?);
        """, (
            data["student_id"],
            data.get("student_name", "Unknown"),
            float(data["predicted_marks"]),
            data["performance_level"],
            data["risk_level"],
            data.get("prediction_date", datetime.now().strftime("%Y-%m-%d %H:%M:%S")),
            data.get("factors_summary", "")
        ))
        conn.commit()
        return cursor.lastrowid


def get_predictions(student_id: Optional[str] = None, limit: Optional[int] = None) -> pd.DataFrame:
    """Fetches prediction history, optionally filtered by student_id with an optional limit."""
    init_db()
    query = "SELECT * FROM predictions"
    params = []
    if student_id:
        query += " WHERE student_id = ?"
        params.append(student_id)

    query += " ORDER BY id DESC"
    if limit:
        query += f" LIMIT {int(limit)}"

    with get_connection() as conn:
        df = pd.read_sql_query(query, conn, params=params)
    return df


def get_dashboard_metrics() -> Dict[str, Any]:
    """Computes and returns core metrics for the analytics dashboard."""
    init_db()
    metrics = {
        "total_students": 0,
        "total_predictions": 0,
        "high_risk_count": 0,
        "well_performing_count": 0,
        "avg_predicted_marks": 0.0,
        "recent_predictions": pd.DataFrame(),
        "performance_distribution": {},
        "attendance_distribution": []
    }

    with get_connection() as conn:
        cursor = conn.cursor()

        # Total registered students
        cursor.execute("SELECT COUNT(*) as count FROM students;")
        metrics["total_students"] = cursor.fetchone()["count"]

        # Total predictions
        cursor.execute("SELECT COUNT(*) as count FROM predictions;")
        metrics["total_predictions"] = cursor.fetchone()["count"]

        # Latest predictions by student (to avoid counting duplicate runs multiple times for dashboard risk stats)
        latest_pred_query = """
            SELECT p.* FROM predictions p
            INNER JOIN (
                SELECT student_id, MAX(id) as max_id
                FROM predictions
                GROUP BY student_id
            ) latest ON p.id = latest.max_id;
        """
        latest_df = pd.read_sql_query(latest_pred_query, conn)

        if not latest_df.empty:
            metrics["high_risk_count"] = int((latest_df["risk_level"] == "High").sum())
            metrics["well_performing_count"] = int(latest_df["performance_level"].isin(["Excellent", "Good"]).sum())
            metrics["avg_predicted_marks"] = round(float(latest_df["predicted_marks"].mean()), 2)
            metrics["performance_distribution"] = latest_df["performance_level"].value_counts().to_dict()
        else:
            # Fallback if no predictions yet: estimate from students table
            cursor.execute("SELECT previous_marks, attendance FROM students;")
            rows = cursor.fetchall()
            if rows:
                high_risk = sum(1 for r in rows if r["previous_marks"] < 50 or r["attendance"] < 65)
                well_perf = sum(1 for r in rows if r["previous_marks"] >= 70 and r["attendance"] >= 75)
                avg_marks = sum(r["previous_marks"] for r in rows) / len(rows)
                metrics["high_risk_count"] = high_risk
                metrics["well_performing_count"] = well_perf
                metrics["avg_predicted_marks"] = round(avg_marks, 2)

        # Recent 10 predictions
        metrics["recent_predictions"] = pd.read_sql_query(
            "SELECT id, student_id, student_name, predicted_marks, performance_level, risk_level, prediction_date FROM predictions ORDER BY id DESC LIMIT 10;",
            conn
        )

        # Attendance list for histogram/distribution
        cursor.execute("SELECT attendance FROM students;")
        metrics["attendance_distribution"] = [r["attendance"] for r in cursor.fetchall()]

    return metrics


# ==========================================
# Database Viewer Introspection Functions
# ==========================================

def get_database_info() -> Dict[str, Any]:
    """Returns database metadata including path, size, and table counts."""
    init_db()
    file_exists = os.path.exists(DB_PATH)
    file_size_kb = round(os.path.getsize(DB_PATH) / 1024, 2) if file_exists else 0.0

    tables = get_table_names()
    table_stats = {}
    for tbl in tables:
        count = get_table_row_count(tbl)
        table_stats[tbl] = count

    return {
        "name": DB_NAME,
        "path": DB_PATH,
        "size_kb": file_size_kb,
        "tables": tables,
        "table_counts": table_stats,
        "last_modified": datetime.fromtimestamp(os.path.getmtime(DB_PATH)).strftime("%Y-%m-%d %H:%M:%S") if file_exists else "N/A"
    }


def get_table_names() -> List[str]:
    """Returns names of all non-system tables in SQLite."""
    init_db()
    with get_connection() as conn:
        cursor = conn.cursor()
        cursor.execute("SELECT name FROM sqlite_master WHERE type='table' AND name NOT LIKE 'sqlite_%' ORDER BY name;")
        return [row["name"] for row in cursor.fetchall()]


def get_table_schema(table_name: str) -> pd.DataFrame:
    """Returns column metadata (cid, name, type, notnull, default, pk) for a table."""
    init_db()
    with get_connection() as conn:
        df = pd.read_sql_query(f"PRAGMA table_info({table_name});", conn)
    return df


def get_table_row_count(table_name: str) -> int:
    """Returns row count for given table."""
    init_db()
    with get_connection() as conn:
        cursor = conn.cursor()
        cursor.execute(f"SELECT COUNT(*) as count FROM {table_name};")
        return cursor.fetchone()["count"]


def get_table_data(table_name: str, limit: Optional[int] = None) -> pd.DataFrame:
    """Returns all rows or up to limit for a table."""
    init_db()
    query = f"SELECT * FROM {table_name} ORDER BY id DESC"
    if limit:
        query += f" LIMIT {int(limit)}"
    with get_connection() as conn:
        df = pd.read_sql_query(query, conn)
    return df


def execute_raw_query(sql_query: str) -> Tuple[bool, Any]:
    """
    Safely executes a read query or returns error message.
    Restricted to SELECT queries for data safety in demo viewer.
    """
    init_db()
    cleaned = sql_query.strip()
    if not cleaned.upper().startswith("SELECT") and not cleaned.upper().startswith("PRAGMA"):
        return False, "For safety, only SELECT and PRAGMA statements are permitted in the Database Console."

    try:
        with get_connection() as conn:
            df = pd.read_sql_query(cleaned, conn)
            return True, df
    except Exception as e:
        return False, str(e)
