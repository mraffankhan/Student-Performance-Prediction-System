"""
app.py - Student Performance Prediction System
Main Application Entry Point & Navigation Portal

BCA Internship / Final Year Academic AIML Project
Technology Stack: Python, SQLite, Random Forest, Scikit-learn/NumPy, Streamlit
"""

import os
import streamlit as st
import database
import model
import data_generator
import ui_components

# Configure page settings
st.set_page_config(
    page_title="Student Performance Prediction System",
    page_icon="🎓",
    layout="wide",
    initial_sidebar_state="expanded"
)

# Apply custom B&W theme
ui_components.apply_custom_theme()

# Ensure Database and ML model are initialized
database.init_db()
data_generator.ensure_dataset_exists()
data_generator.seed_initial_database_if_empty()
model.ensure_model_trained()

# Render persistent sidebar
ui_components.render_sidebar()

# Page Header
ui_components.render_page_header(
    title="STUDENT PERFORMANCE PREDICTION SYSTEM",
    subtitle="AI-Powered Academic Analytics, Risk Identification & Early Intervention Platform"
)

# Core Metrics Row
metrics = database.get_dashboard_metrics()
col1, col2, col3, col4 = st.columns(4)

with col1:
    st.markdown(ui_components.metric_card(
        title="Total Registered Students",
        value=metrics["total_students"],
        subtitle="Stored in local SQLite database"
    ), unsafe_allow_html=True)

with col2:
    st.markdown(ui_components.metric_card(
        title="Total Predictions Generated",
        value=metrics["total_predictions"],
        subtitle="Evaluated using Random Forest"
    ), unsafe_allow_html=True)

with col3:
    st.markdown(ui_components.metric_card(
        title="Students at Academic Risk",
        value=metrics["high_risk_count"],
        subtitle="Requiring targeted faculty support"
    ), unsafe_allow_html=True)

with col4:
    st.markdown(ui_components.metric_card(
        title="Avg. Predicted Marks",
        value=f"{metrics['avg_predicted_marks']}%",
        subtitle="Overall cohort performance"
    ), unsafe_allow_html=True)

st.markdown("<br>", unsafe_allow_html=True)

# Module Navigation Grid
st.markdown("### System Navigation")
st.markdown("Select a module below or use the sidebar to navigate the platform:")

row1_col1, row1_col2, row1_col3 = st.columns(3)

with row1_col1:
    st.markdown(
        """
        <div class="bw-card">
            <h3 style="margin: 0 0 0.5rem 0; font-size: 1.15rem; color: #000;">1. Dashboard</h3>
            <p style="font-size: 0.85rem; color: #555; line-height: 1.4;">
                Overview of cohort KPIs, attendance vs. marks distributions, risk levels, and recent prediction activity.
            </p>
        </div>
        """,
        unsafe_allow_html=True
    )
    if st.button("Open Dashboard", key="btn_nav_dashboard", use_container_width=True):
        st.switch_page("pages/1_Dashboard.py")

with row1_col2:
    st.markdown(
        """
        <div class="bw-card">
            <h3 style="margin: 0 0 0.5rem 0; font-size: 1.15rem; color: #000;">2. Add Student</h3>
            <p style="font-size: 0.85rem; color: #555; line-height: 1.4;">
                Register a new student with attendance, study hours, previous exam marks, and internal assessment records.
            </p>
        </div>
        """,
        unsafe_allow_html=True
    )
    if st.button("Add New Student", key="btn_nav_add_student", use_container_width=True):
        st.switch_page("pages/2_Add_Student.py")

with row1_col3:
    st.markdown(
        """
        <div class="bw-card">
            <h3 style="margin: 0 0 0.5rem 0; font-size: 1.15rem; color: #000;">3. Predict Performance</h3>
            <p style="font-size: 0.85rem; color: #555; line-height: 1.4;">
                Run the trained Random Forest model to compute expected marks, performance tiers, risk categories, and factor explanations.
            </p>
        </div>
        """,
        unsafe_allow_html=True
    )
    if st.button("Run Prediction", key="btn_nav_predict", use_container_width=True):
        st.switch_page("pages/3_Predict_Performance.py")

st.markdown("<br>", unsafe_allow_html=True)
row2_col1, row2_col2, row2_col3 = st.columns(3)

with row2_col1:
    st.markdown(
        """
        <div class="bw-card">
            <h3 style="margin: 0 0 0.5rem 0; font-size: 1.15rem; color: #000;">4. Student Records</h3>
            <p style="font-size: 0.85rem; color: #555; line-height: 1.4;">
                Searchable, filterable student registry. Inspect profiles, update details, or remove records with SQLite synchronization.
            </p>
        </div>
        """,
        unsafe_allow_html=True
    )
    if st.button("View Records", key="btn_nav_records", use_container_width=True):
        st.switch_page("pages/4_Student_Records.py")

with row2_col2:
    st.markdown(
        """
        <div class="bw-card">
            <h3 style="margin: 0 0 0.5rem 0; font-size: 1.15rem; color: #000;">5. Database Viewer</h3>
            <p style="font-size: 0.85rem; color: #555; line-height: 1.4;">
                Direct in-app SQLite viewer: inspect database tables, schemas, row counts, and execute read-only SQL queries.
            </p>
        </div>
        """,
        unsafe_allow_html=True
    )
    if st.button("Open Database Viewer", key="btn_nav_db", use_container_width=True):
        st.switch_page("pages/5_Database.py")

with row2_col3:
    st.markdown(
        """
        <div class="bw-card">
            <h3 style="margin: 0 0 0.5rem 0; font-size: 1.15rem; color: #000;">6. Reports & Analytics</h3>
            <p style="font-size: 0.85rem; color: #555; line-height: 1.4;">
                Generate individual student performance reports, view ML model evaluation metrics (MAE, R², F1), and export CSV reports.
            </p>
        </div>
        """,
        unsafe_allow_html=True
    )
    if st.button("View Reports", key="btn_nav_reports", use_container_width=True):
        st.switch_page("pages/6_Reports_Analytics.py")

st.markdown("<br><hr>", unsafe_allow_html=True)

# Technical Architecture Overview
st.markdown("### Technical Architecture & Academic Specifications")
tech_col1, tech_col2 = st.columns(2)

with tech_col1:
    st.markdown(
        """
        **System Components:**
        - **Machine Learning Core:** Random Forest Regressor & Classifier trained on verified academic features.
        - **Model Persistence:** Serialized model artifacts stored locally in `models/random_forest_model.pkl`.
        - **Database Layer:** Local SQLite database `student_performance.db` using relational foreign keys.
        - **Frontend Presentation:** Streamlit multipage application adhering to a pure monochrome design.
        """
    )

with tech_col2:
    st.markdown(
        """
        **Academic Features Evaluated:**
        - **Attendance (%):** Lecture regularity and class engagement.
        - **Previous Marks (%):** Historical examination foundation.
        - **Study Hours (hrs/day):** Independent academic dedication.
        - **Assignment Completion (%):** Continuous assessment completion.
        - **Internal Marks (%):** Mid-term and practical coursework ratings.
        """
    )

st.markdown(
    """
    <div class="disclaimer-box">
        <strong>Academic Disclaimer:</strong> Predictions generated by this system are analytical estimates intended to assist educators in academic advising and early intervention. They should not be treated as a definitive judgment of a student's potential.
    </div>
    """,
    unsafe_allow_html=True
)

