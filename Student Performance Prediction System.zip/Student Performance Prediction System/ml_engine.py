"""
ml_engine.py - Pure NumPy Machine Learning Engine & Scikit-Learn Fallback
Student Performance Prediction System

Provides a fast, high-performance Random Forest Regressor & Classifier built on NumPy.
If Scikit-Learn's C-extensions are blocked by Windows Defender / Smart App Control,
this engine guarantees 100% functionality with real mathematical implementations of:
- Decision Trees (MSE reduction for regression, Gini impurity for classification)
- Random Forest Ensembles (Bootstrap aggregation, random feature subspace)
- Feature Importance Calculation (Mean decrease in impurity / variance)
- Real Evaluation Metrics: MAE, RMSE, R², Accuracy, Precision, Recall, F1, Confusion Matrix
"""

import numpy as np
from typing import List, Dict, Any, Tuple, Optional


# =====================================================================
# Real Metrics Implementations
# =====================================================================

def mean_absolute_error(y_true: np.ndarray, y_pred: np.ndarray) -> float:
    return float(np.mean(np.abs(y_true - y_pred)))


def root_mean_squared_error(y_true: np.ndarray, y_pred: np.ndarray) -> float:
    return float(np.sqrt(np.mean((y_true - y_pred) ** 2)))


def r2_score(y_true: np.ndarray, y_pred: np.ndarray) -> float:
    ss_tot = np.sum((y_true - np.mean(y_true)) ** 2)
    ss_res = np.sum((y_true - y_pred) ** 2)
    if ss_tot == 0:
        return 1.0
    return float(1.0 - (ss_res / ss_tot))


def accuracy_score(y_true: np.ndarray, y_pred: np.ndarray) -> float:
    return float(np.mean(y_true == y_pred))


def classification_report_metrics(y_true: np.ndarray, y_pred: np.ndarray, classes: List[str]) -> Tuple[float, float, float, np.ndarray]:
    """Calculates weighted precision, recall, f1, and confusion matrix."""
    n_classes = len(classes)
    class_to_idx = {c: i for i, c in enumerate(classes)}
    cm = np.zeros((n_classes, n_classes), dtype=int)

    for yt, yp in zip(y_true, y_pred):
        if yt in class_to_idx and yp in class_to_idx:
            cm[class_to_idx[yt], class_to_idx[yp]] += 1

    total = len(y_true)
    if total == 0:
        return 0.0, 0.0, 0.0, cm

    precisions = []
    recalls = []
    f1s = []
    weights = []

    for i in range(n_classes):
        tp = cm[i, i]
        fp = np.sum(cm[:, i]) - tp
        fn = np.sum(cm[i, :]) - tp
        support = np.sum(cm[i, :])

        prec = tp / (tp + fp) if (tp + fp) > 0 else 0.0
        rec = tp / (tp + fn) if (tp + fn) > 0 else 0.0
        f1 = (2 * prec * rec) / (prec + rec) if (prec + rec) > 0 else 0.0

        precisions.append(prec)
        recalls.append(rec)
        f1s.append(f1)
        weights.append(support)

    weighted_prec = float(np.average(precisions, weights=weights)) if sum(weights) > 0 else 0.0
    weighted_rec = float(np.average(recalls, weights=weights)) if sum(weights) > 0 else 0.0
    weighted_f1 = float(np.average(f1s, weights=weights)) if sum(weights) > 0 else 0.0

    return weighted_prec, weighted_rec, weighted_f1, cm


# =====================================================================
# Decision Tree & Random Forest Regressor
# =====================================================================

class Node:
    def __init__(self, feature=None, threshold=None, left=None, right=None, *, value=None):
        self.feature = feature
        self.threshold = threshold
        self.left = left
        self.right = right
        self.value = value

    @property
    def is_leaf(self):
        return self.value is not None


class DecisionTreeRegressor:
    def __init__(self, max_depth=10, min_samples_split=4, max_features=None, random_state=None):
        self.max_depth = max_depth
        self.min_samples_split = min_samples_split
        self.max_features = max_features
        self.random_state = random_state
        self.rng = np.random.RandomState(random_state)
        self.root = None
        self.feature_importances_ = None

    def fit(self, X: np.ndarray, y: np.ndarray):
        n_features = X.shape[1]
        self.feature_importances_ = np.zeros(n_features)
        self.root = self._grow_tree(X, y, depth=0)
        total_imp = np.sum(self.feature_importances_)
        if total_imp > 0:
            self.feature_importances_ /= total_imp
        return self

    def _grow_tree(self, X: np.ndarray, y: np.ndarray, depth: int = 0) -> Node:
        n_samples, n_features = X.shape
        if (depth >= self.max_depth or n_samples < self.min_samples_split or len(np.unique(y)) == 1):
            return Node(value=float(np.mean(y)))

        # Subsample features if max_features set
        feat_idxs = np.arange(n_features)
        if self.max_features is not None:
            n_sub = min(n_features, max(1, int(self.max_features)))
            feat_idxs = self.rng.choice(n_features, n_sub, replace=False)

        best_feat, best_thresh, best_var_red = self._best_split(X, y, feat_idxs)
        if best_feat is None or best_var_red <= 1e-7:
            return Node(value=float(np.mean(y)))

        self.feature_importances_[best_feat] += best_var_red * n_samples

        left_mask = X[:, best_feat] <= best_thresh
        right_mask = ~left_mask

        left_node = self._grow_tree(X[left_mask], y[left_mask], depth + 1)
        right_node = self._grow_tree(X[right_mask], y[right_mask], depth + 1)
        return Node(feature=best_feat, threshold=best_thresh, left=left_node, right=right_node)

    def _best_split(self, X: np.ndarray, y: np.ndarray, feat_idxs: np.ndarray):
        best_var_red = -1.0
        split_feat, split_thresh = None, None
        parent_var = np.var(y)
        n = len(y)

        for feat in feat_idxs:
            X_column = X[:, feat]
            thresholds = np.percentile(X_column, q=np.linspace(10, 90, 9))
            for thresh in thresholds:
                left_mask = X_column <= thresh
                right_mask = ~left_mask
                if np.sum(left_mask) < 2 or np.sum(right_mask) < 2:
                    continue
                n_l, n_r = np.sum(left_mask), np.sum(right_mask)
                var_l = np.var(y[left_mask])
                var_r = np.var(y[right_mask])
                var_red = parent_var - ((n_l / n) * var_l + (n_r / n) * var_r)
                if var_red > best_var_red:
                    best_var_red = var_red
                    split_feat = feat
                    split_thresh = thresh

        return split_feat, split_thresh, best_var_red

    def predict(self, X: np.ndarray) -> np.ndarray:
        return np.array([self._traverse_tree(x, self.root) for x in X])

    def _traverse_tree(self, x: np.ndarray, node: Node) -> float:
        if node.is_leaf:
            return node.value
        if x[node.feature] <= node.threshold:
            return self._traverse_tree(x, node.left)
        return self._traverse_tree(x, node.right)


class RandomForestRegressor:
    def __init__(self, n_estimators=60, max_depth=10, min_samples_split=4, max_features="sqrt", random_state=42):
        self.n_estimators = n_estimators
        self.max_depth = max_depth
        self.min_samples_split = min_samples_split
        self.max_features = max_features
        self.random_state = random_state
        self.trees: List[DecisionTreeRegressor] = []
        self.feature_importances_ = None

    def fit(self, X: np.ndarray, y: np.ndarray):
        X = np.asarray(X, dtype=float)
        y = np.asarray(y, dtype=float)
        n_samples, n_features = X.shape
        rng = np.random.RandomState(self.random_state)

        if self.max_features == "sqrt":
            max_f = int(np.sqrt(n_features))
        else:
            max_f = n_features

        self.trees = []
        importances = np.zeros(n_features)

        for i in range(self.n_estimators):
            # Bootstrap sample
            boot_idxs = rng.choice(n_samples, n_samples, replace=True)
            tree = DecisionTreeRegressor(
                max_depth=self.max_depth,
                min_samples_split=self.min_samples_split,
                max_features=max_f,
                random_state=rng.randint(0, 100000)
            )
            tree.fit(X[boot_idxs], y[boot_idxs])
            self.trees.append(tree)
            if tree.feature_importances_ is not None:
                importances += tree.feature_importances_

        self.feature_importances_ = importances / self.n_estimators
        if np.sum(self.feature_importances_) > 0:
            self.feature_importances_ /= np.sum(self.feature_importances_)
        return self

    def predict(self, X: np.ndarray) -> np.ndarray:
        X = np.asarray(X, dtype=float)
        tree_preds = np.array([tree.predict(X) for tree in self.trees])
        return np.mean(tree_preds, axis=0)


# =====================================================================
# Decision Tree & Random Forest Classifier
# =====================================================================

class DecisionTreeClassifier:
    def __init__(self, max_depth=8, min_samples_split=4, max_features=None, random_state=None):
        self.max_depth = max_depth
        self.min_samples_split = min_samples_split
        self.max_features = max_features
        self.random_state = random_state
        self.rng = np.random.RandomState(random_state)
        self.root = None
        self.classes_ = None

    def fit(self, X: np.ndarray, y: np.ndarray):
        self.classes_ = np.unique(y)
        self.root = self._grow_tree(X, y, depth=0)
        return self

    def _gini(self, y: np.ndarray) -> float:
        m = len(y)
        if m == 0:
            return 0.0
        _, counts = np.unique(y, return_counts=True)
        return 1.0 - np.sum((counts / m) ** 2)

    def _grow_tree(self, X: np.ndarray, y: np.ndarray, depth: int = 0) -> Node:
        n_samples, n_features = X.shape
        vals, counts = np.unique(y, return_counts=True)
        majority_class = vals[np.argmax(counts)]

        if (depth >= self.max_depth or n_samples < self.min_samples_split or len(vals) == 1):
            return Node(value=majority_class)

        feat_idxs = np.arange(n_features)
        if self.max_features is not None:
            n_sub = min(n_features, max(1, int(self.max_features)))
            feat_idxs = self.rng.choice(n_features, n_sub, replace=False)

        best_feat, best_thresh, best_gain = self._best_split(X, y, feat_idxs)
        if best_feat is None or best_gain <= 1e-7:
            return Node(value=majority_class)

        left_mask = X[:, best_feat] <= best_thresh
        right_mask = ~left_mask

        left_node = self._grow_tree(X[left_mask], y[left_mask], depth + 1)
        right_node = self._grow_tree(X[right_mask], y[right_mask], depth + 1)
        return Node(feature=best_feat, threshold=best_thresh, left=left_node, right=right_node)

    def _best_split(self, X: np.ndarray, y: np.ndarray, feat_idxs: np.ndarray):
        best_gain = -1.0
        split_feat, split_thresh = None, None
        parent_gini = self._gini(y)
        n = len(y)

        for feat in feat_idxs:
            X_column = X[:, feat]
            thresholds = np.percentile(X_column, q=np.linspace(15, 85, 7))
            for thresh in thresholds:
                left_mask = X_column <= thresh
                right_mask = ~left_mask
                if np.sum(left_mask) < 2 or np.sum(right_mask) < 2:
                    continue
                n_l, n_r = np.sum(left_mask), np.sum(right_mask)
                gini_l = self._gini(y[left_mask])
                gini_r = self._gini(y[right_mask])
                gain = parent_gini - ((n_l / n) * gini_l + (n_r / n) * gini_r)
                if gain > best_gain:
                    best_gain = gain
                    split_feat = feat
                    split_thresh = thresh

        return split_feat, split_thresh, best_gain

    def predict(self, X: np.ndarray) -> np.ndarray:
        return np.array([self._traverse_tree(x, self.root) for x in X])

    def _traverse_tree(self, x: np.ndarray, node: Node):
        if node.is_leaf:
            return node.value
        if x[node.feature] <= node.threshold:
            return self._traverse_tree(x, node.left)
        return self._traverse_tree(x, node.right)


class RandomForestClassifier:
    def __init__(self, n_estimators=60, max_depth=8, min_samples_split=4, max_features="sqrt", random_state=42):
        self.n_estimators = n_estimators
        self.max_depth = max_depth
        self.min_samples_split = min_samples_split
        self.max_features = max_features
        self.random_state = random_state
        self.trees: List[DecisionTreeClassifier] = []
        self.classes_ = None

    def fit(self, X: np.ndarray, y: np.ndarray):
        X = np.asarray(X, dtype=float)
        y = np.asarray(y)
        self.classes_ = np.unique(y)
        n_samples, n_features = X.shape
        rng = np.random.RandomState(self.random_state)

        if self.max_features == "sqrt":
            max_f = int(np.sqrt(n_features))
        else:
            max_f = n_features

        self.trees = []
        for _ in range(self.n_estimators):
            boot_idxs = rng.choice(n_samples, n_samples, replace=True)
            tree = DecisionTreeClassifier(
                max_depth=self.max_depth,
                min_samples_split=self.min_samples_split,
                max_features=max_f,
                random_state=rng.randint(0, 100000)
            )
            tree.fit(X[boot_idxs], y[boot_idxs])
            self.trees.append(tree)
        return self

    def predict(self, X: np.ndarray) -> np.ndarray:
        X = np.asarray(X, dtype=float)
        preds = np.array([tree.predict(X) for tree in self.trees])
        # Majority voting
        majority = []
        for i in range(X.shape[0]):
            col = preds[:, i]
            vals, counts = np.unique(col, return_counts=True)
            majority.append(vals[np.argmax(counts)])
        return np.array(majority)


# =====================================================================
# Feature Transformer & Matrix Builder
# =====================================================================

class FeatureTransformer:
    """Preprocesses mixed numeric and categorical features into a normalized float matrix."""
    def __init__(self, numeric_cols: List[str], categorical_cols: List[str]):
        self.numeric_cols = numeric_cols
        self.categorical_cols = categorical_cols
        self.num_means_ = {}
        self.num_stds_ = {}
        self.categories_ = {}
        self.feature_names_out_ = []

    def fit(self, df):
        # Learn mean & std for numeric
        for col in self.numeric_cols:
            vals = np.array([float(x) for x in df[col]], dtype=float)
            self.num_means_[col] = float(np.mean(vals))
            std = float(np.std(vals))
            self.num_stds_[col] = std if std > 1e-6 else 1.0

        # Learn unique categories
        for col in self.categorical_cols:
            cats = sorted(list(set(str(x) for x in df[col])))
            self.categories_[col] = cats

        # Output feature names
        names = list(self.numeric_cols)
        for col in self.categorical_cols:
            for cat in self.categories_[col]:
                names.append(f"{col}_{cat}")
        self.feature_names_out_ = names
        return self

    def transform(self, df) -> np.ndarray:
        n_rows = len(df)
        cols_data = []

        # Scaled numeric features
        for col in self.numeric_cols:
            raw = np.array([float(x) for x in df[col]], dtype=float)
            scaled = (raw - self.num_means_[col]) / self.num_stds_[col]
            cols_data.append(scaled.reshape(-1, 1))

        # One-hot encoded categorical features
        for col in self.categorical_cols:
            raw_vals = [str(x) for x in df[col]]
            cats = self.categories_[col]
            one_hot = np.zeros((n_rows, len(cats)), dtype=float)
            cat_map = {c: i for i, c in enumerate(cats)}
            for r_idx, val in enumerate(raw_vals):
                if val in cat_map:
                    one_hot[r_idx, cat_map[val]] = 1.0
            cols_data.append(one_hot)

        return np.hstack(cols_data)

    def fit_transform(self, df) -> np.ndarray:
        return self.fit(df).transform(df)

