"""
preprocessing.py - Data Preprocessing & Validation Module
Student Performance Prediction System

Provides feature definitions, scikit-learn transformers, input validation,
and helper functions for classifying performance and risk tiers.
"""

from typing import Dict, Any, Tuple, List, Optional
import numpy as np
import compat_pandas as pd

# Core feature definitions
NUMERIC_FEATURES = [
    "attendance",
    "previous_marks",
    "study_hours",
    "assignment_completion",
    "internal_marks",
    "age"
]

CATEGORICAL_FEATURES = [
    "semester",
    "gender",
    "extracurricular"
]

ALL_FEATURE_COLUMNS = NUMERIC_FEATURES + CATEGORICAL_FEATURES

SEMESTER_OPTIONS = [
    "Semester 1", "Semester 2", "Semester 3",
    "Semester 4", "Semester 5", "Semester 6",
    "Semester 7", "Semester 8"
]

GENDER_OPTIONS = ["Female", "Male", "Other", "Unspecified"]
EXTRACURRICULAR_OPTIONS = ["Yes", "No"]


def validate_student_data(data: Dict[str, Any]) -> Tuple[bool, Optional[str]]:
    """
    Validates form data before saving to SQLite or predicting.
    Returns (True, None) if valid, or (False, error_description) if invalid.
    """
    name = str(data.get("student_name", "")).strip()
    if not name or len(name) < 2:
        return False, "Student Name must be at least 2 characters long."
    
    try:
        age = int(data.get("age", 0))
        if age < 15 or age > 60:
            return False, "Age must be between 15 and 60 years."
    except (ValueError, TypeError):
        return False, "Age must be a valid integer."

    try:
        attendance = float(data.get("attendance", -1))
        if not (0.0 <= attendance <= 100.0):
            return False, "Attendance percentage must be between 0.0% and 100.0%."
    except (ValueError, TypeError):
        return False, "Attendance must be a valid number."

    try:
        previous_marks = float(data.get("previous_marks", -1))
        if not (0.0 <= previous_marks <= 100.0):
            return False, "Previous Examination Marks must be between 0.0 and 100.0."
    except (ValueError, TypeError):
        return False, "Previous Marks must be a valid number."

    try:
        study_hours = float(data.get("study_hours", -1))
        if not (0.0 <= study_hours <= 24.0):
            return False, "Study Hours Per Day must be between 0.0 and 24.0 hours."
    except (ValueError, TypeError):
        return False, "Study Hours must be a valid number."

    try:
        assignment_completion = float(data.get("assignment_completion", -1))
        if not (0.0 <= assignment_completion <= 100.0):
            return False, "Assignment Completion must be between 0.0% and 100.0%."
    except (ValueError, TypeError):
        return False, "Assignment Completion must be a valid number."

    try:
        internal_marks = float(data.get("internal_marks", -1))
        if not (0.0 <= internal_marks <= 100.0):
            return False, "Internal Assessment Marks must be between 0.0 and 100.0."
    except (ValueError, TypeError):
        return False, "Internal Marks must be a valid number."

    semester = data.get("semester")
    if semester not in SEMESTER_OPTIONS:
        return False, f"Semester must be one of: {', '.join(SEMESTER_OPTIONS)}."

    return True, None


def categorize_performance(marks: float) -> str:
    """
    Maps numerical predicted marks to academic performance tier:
    - Excellent: >= 80%
    - Good: 65% - 79.9%
    - Average: 50% - 64.9%
    - Needs Improvement: < 50%
    """
    if marks >= 80.0:
        return "Excellent"
    elif marks >= 65.0:
        return "Good"
    elif marks >= 50.0:
        return "Average"
    else:
        return "Needs Improvement"


def determine_risk_level(predicted_marks: float, attendance: float, previous_marks: float) -> str:
    """
    Determines academic risk tier based on predicted score, attendance, and past record:
    - High Risk: Predicted marks < 50 OR (attendance < 60% and previous marks < 55)
    - Medium Risk: 50 <= marks < 65 OR attendance < 75%
    - Low Risk: Marks >= 65 and attendance >= 75%
    """
    if predicted_marks < 50.0 or (attendance < 60.0 and previous_marks < 55.0):
        return "High"
    elif predicted_marks < 65.0 or attendance < 75.0 or previous_marks < 60.0:
        return "Medium"
    else:
        return "Low"
