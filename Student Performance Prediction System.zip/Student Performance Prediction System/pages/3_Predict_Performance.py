"""
pages/3_Predict_Performance.py - Academic Performance Prediction Module
Student Performance Prediction System

Provides Random Forest evaluation for existing registered students or new ad-hoc profiles,
computing expected marks, performance levels, risk indicators, factor importance charts,
and actionable academic explanations.
"""

import streamlit as st
import plotly.graph_objects as go
import database
import model
import preprocessing
import ui_components

st.set_page_config(
    page_title="Predict Performance | Student Performance Prediction System",
    page_icon="🎯",
    layout="wide"
)

# Apply B&W theme
ui_components.apply_custom_theme()
database.init_db()
model.ensure_model_trained()
ui_components.render_sidebar()

ui_components.render_page_header(
    title="ACADEMIC PERFORMANCE PREDICTION",
    subtitle="Evaluate expected examination performance and identify risk factors using the trained Random Forest model."
)

# Mode selector: Existing student vs Manual entry
input_mode = st.radio(
    "Select Evaluation Mode:",
    options=["Select Registered Student from Database", "Enter Custom / Ad-hoc Student Data"],
    horizontal=True
)

selected_student_data = None

if input_mode == "Select Registered Student from Database":
    all_students_df = database.get_all_students()
    if all_students_df.empty:
        st.warning("No registered students found in the database. Please register a student first or switch to custom data entry.")
    else:
        # Create student selector list
        student_records = all_students_df.to_dict(orient="records")
        student_options = {
            f"{s['student_id']} - {s['student_name']} ({s['semester']})": s
            for s in student_records
        }
        chosen_label = st.selectbox("Select Student:", options=list(student_options.keys()))
        selected_student_data = student_options[chosen_label]

# Form container
with st.container():
    st.markdown('<div class="bw-card">', unsafe_allow_html=True)
    st.markdown("#### Student Attributes & Academic Indicators")

    col1, col2, col3 = st.columns(3)

    if selected_student_data:
        # Prepopulate with existing student
        with col1:
            eval_name = st.text_input("Student Name", value=selected_student_data["student_name"])
            eval_age = st.number_input("Age", min_value=15, max_value=60, value=int(selected_student_data["age"]))
            eval_gender = st.selectbox("Gender", options=preprocessing.GENDER_OPTIONS, index=preprocessing.GENDER_OPTIONS.index(selected_student_data.get("gender", "Unspecified")) if selected_student_data.get("gender") in preprocessing.GENDER_OPTIONS else 1)
        with col2:
            sem_idx = preprocessing.SEMESTER_OPTIONS.index(selected_student_data["semester"]) if selected_student_data["semester"] in preprocessing.SEMESTER_OPTIONS else 0
            eval_sem = st.selectbox("Semester", options=preprocessing.SEMESTER_OPTIONS, index=sem_idx)
            eval_att = st.number_input("Attendance (%)", min_value=0.0, max_value=100.0, value=float(selected_student_data["attendance"]), step=0.5)
            eval_prev = st.number_input("Previous Marks (%)", min_value=0.0, max_value=100.0, value=float(selected_student_data["previous_marks"]), step=0.5)
        with col3:
            eval_study = st.number_input("Study Hours/Day", min_value=0.0, max_value=24.0, value=float(selected_student_data["study_hours"]), step=0.5)
            eval_assign = st.number_input("Assignment Completion (%)", min_value=0.0, max_value=100.0, value=float(selected_student_data["assignment_completion"]), step=0.5)
            eval_intern = st.number_input("Internal Marks (%)", min_value=0.0, max_value=100.0, value=float(selected_student_data["internal_marks"]), step=0.5)
            extra_idx = 0 if selected_student_data.get("extracurricular") == "Yes" else 1
            eval_extra = st.selectbox("Extracurricular", options=preprocessing.EXTRACURRICULAR_OPTIONS, index=extra_idx)
        eval_id = selected_student_data["student_id"]
    else:
        # Defaults for custom entry
        with col1:
            eval_name = st.text_input("Student Name", value="Ad-hoc Candidate")
            eval_age = st.number_input("Age", min_value=15, max_value=60, value=20)
            eval_gender = st.selectbox("Gender", options=preprocessing.GENDER_OPTIONS, index=1)
        with col2:
            eval_sem = st.selectbox("Semester", options=preprocessing.SEMESTER_OPTIONS, index=2)
            eval_att = st.number_input("Attendance (%)", min_value=0.0, max_value=100.0, value=75.0, step=0.5)
            eval_prev = st.number_input("Previous Marks (%)", min_value=0.0, max_value=100.0, value=65.0, step=0.5)
        with col3:
            eval_study = st.number_input("Study Hours/Day", min_value=0.0, max_value=24.0, value=3.5, step=0.5)
            eval_assign = st.number_input("Assignment Completion (%)", min_value=0.0, max_value=100.0, value=75.0, step=0.5)
            eval_intern = st.number_input("Internal Marks (%)", min_value=0.0, max_value=100.0, value=68.0, step=0.5)
            eval_extra = st.selectbox("Extracurricular", options=preprocessing.EXTRACURRICULAR_OPTIONS, index=1)
        eval_id = "CUSTOM-EVAL"

    st.markdown("<hr style='margin: 1.25rem 0;'>", unsafe_allow_html=True)

    predict_btn = st.button("Generate Performance Prediction", use_container_width=True)
    st.markdown('</div>', unsafe_allow_html=True)

# Prediction Result Processing
if predict_btn:
    eval_dict = {
        "student_id": eval_id,
        "student_name": eval_name,
        "age": eval_age,
        "gender": eval_gender,
        "semester": eval_sem,
        "attendance": eval_att,
        "previous_marks": eval_prev,
        "study_hours": eval_study,
        "assignment_completion": eval_assign,
        "internal_marks": eval_intern,
        "extracurricular": eval_extra
    }

    is_valid, err_msg = preprocessing.validate_student_data(eval_dict)
    if not is_valid:
        st.error(f"Input Validation Error: {err_msg}")
    else:
        # Run inference
        pred_res = model.predict_student_performance(eval_dict)

        # Save to SQLite if it is a registered student
        if selected_student_data:
            database.add_prediction({
                "student_id": eval_id,
                "student_name": eval_name,
                "predicted_marks": pred_res["predicted_marks"],
                "performance_level": pred_res["performance_level"],
                "risk_level": pred_res["risk_level"],
                "factors_summary": pred_res["explanation"]
            })

        st.markdown("<br>", unsafe_allow_html=True)
        st.markdown("### Prediction Results & Diagnostic Analysis")

        # Result Banner
        res_col1, res_col2, res_col3 = st.columns([1.5, 1, 1])

        with res_col1:
            st.markdown(
                f"""
                <div class="prediction-box">
                    <div style="font-size: 0.85rem; font-weight: 700; color: #64748b; text-transform: uppercase;">Expected Academic Marks</div>
                    <div class="prediction-score">{pred_res['predicted_marks']}%</div>
                    <div class="prediction-tier">Performance Tier: <strong>{pred_res['performance_level']}</strong></div>
                    <div style="margin-top: 0.75rem;">
                        Risk Assessment: {ui_components.get_risk_badge_html(pred_res['risk_level'])}
                    </div>
                </div>
                """,
                unsafe_allow_html=True
            )

        with res_col2:
            st.markdown(
                f"""
                <div class="bw-card">
                    <div class="bw-card-header">Academic Foundation</div>
                    <div style="font-size: 1.1rem; font-weight: 700; margin-top: 0.5rem;">Previous: {eval_prev}%</div>
                    <div style="font-size: 1.1rem; font-weight: 700; margin-top: 0.35rem;">Internal: {eval_intern}%</div>
                    <div class="bw-card-sub" style="margin-top: 0.75rem;">Key drivers of exam readiness</div>
                </div>
                """,
                unsafe_allow_html=True
            )

        with res_col3:
            st.markdown(
                f"""
                <div class="bw-card">
                    <div class="bw-card-header">Behavioral Discipline</div>
                    <div style="font-size: 1.1rem; font-weight: 700; margin-top: 0.5rem;">Attendance: {eval_att}%</div>
                    <div style="font-size: 1.1rem; font-weight: 700; margin-top: 0.35rem;">Study: {eval_study} hrs/day</div>
                    <div class="bw-card-sub" style="margin-top: 0.75rem;">Assignment: {eval_assign}%</div>
                </div>
                """,
                unsafe_allow_html=True
            )

        # Explanation Box
        st.markdown(
            f"""
            <div style="background: #ffffff; border: 1px solid #000000; border-radius: 6px; padding: 1.25rem; margin-top: 1rem;">
                <h4 style="margin: 0 0 0.5rem 0; font-size: 1rem; color: #000000;">AI Academic Explanation</h4>
                <p style="margin: 0; font-size: 0.92rem; color: #333333; line-height: 1.5;">{pred_res['explanation']}</p>
            </div>
            """,
            unsafe_allow_html=True
        )

        st.markdown("<br>", unsafe_allow_html=True)

        # Factor Importances Chart
        st.markdown("#### Random Forest Key Influencing Factors")
        imp_data = pred_res.get("feature_importances", [])
        if imp_data:
            feats = [item["feature"] for item in reversed(imp_data[:6])]
            vals = [item["importance"] * 100 for item in reversed(imp_data[:6])]

            fig_imp = go.Figure(go.Bar(
                x=vals,
                y=feats,
                orientation='h',
                marker=dict(color="#111111", line=dict(color="#000000", width=1))
            ))
            fig_imp.update_layout(
                title=dict(text="Relative Feature Importance in Model Decision (% Contribution)", font=dict(family="Inter", size=14)),
                xaxis=dict(title="Relative Contribution (%)", showgrid=True, gridcolor="#f1f5f9"),
                yaxis=dict(showgrid=False),
                plot_bgcolor="#ffffff",
                paper_bgcolor="#ffffff",
                height=280,
                margin=dict(l=140, r=20, t=40, b=40)
            )
            st.plotly_chart(fig_imp, use_container_width=True)

        # Disclaimer
        st.markdown(
            """
            <div class="disclaimer-box">
                <strong>Academic Disclaimer:</strong> Predictions generated by this system are analytical estimates intended to assist educators in academic advising and early intervention. They should not be treated as a definitive judgment of a student's potential.
            </div>
            """,
            unsafe_allow_html=True
        )

