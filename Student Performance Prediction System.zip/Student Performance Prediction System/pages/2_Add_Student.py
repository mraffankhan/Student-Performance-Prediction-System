"""
pages/2_Add_Student.py - Student Registration Module
Student Performance Prediction System

Provides a validated student registration form that saves student records
directly into the local SQLite database.
"""

import streamlit as st
import database
import preprocessing
import model
import ui_components

st.set_page_config(
    page_title="Add Student | Student Performance Prediction System",
    page_icon="👤",
    layout="wide"
)

# Apply B&W theme
ui_components.apply_custom_theme()
database.init_db()
ui_components.render_sidebar()

ui_components.render_page_header(
    title="STUDENT REGISTRATION",
    subtitle="Register a new student with academic history, behavioral indicators, and examination scores."
)

# Generate next sequential ID
next_id = database.get_next_student_id()

# Registration Form Card
with st.container():
    st.markdown('<div class="bw-card">', unsafe_allow_html=True)
    st.markdown("#### Academic & Profile Information")
    st.caption("All numerical marks, percentages, and hours are strictly validated prior to saving into SQLite.")

    with st.form("add_student_form", clear_on_submit=False):
        col1, col2, col3 = st.columns(3)

        with col1:
            st.text_input("Student ID (Auto-generated)", value=next_id, disabled=True, help="Assigned sequentially by SQLite")
            student_name = st.text_input("Student Full Name *", placeholder="e.g. Rahul Sharma")
            age = st.number_input("Age *", min_value=15, max_value=60, value=20, step=1)
            gender = st.selectbox("Gender", options=preprocessing.GENDER_OPTIONS, index=1)

        with col2:
            semester = st.selectbox("Class / Semester *", options=preprocessing.SEMESTER_OPTIONS, index=2)
            attendance = st.number_input("Attendance Percentage (%) *", min_value=0.0, max_value=100.0, value=75.0, step=0.5, format="%.1f")
            previous_marks = st.number_input("Previous Examination Marks (%) *", min_value=0.0, max_value=100.0, value=68.0, step=0.5, format="%.1f")
            study_hours = st.number_input("Study Hours Per Day (hrs) *", min_value=0.0, max_value=24.0, value=4.0, step=0.5, format="%.1f")

        with col3:
            assignment_completion = st.number_input("Assignment Completion (%) *", min_value=0.0, max_value=100.0, value=80.0, step=0.5, format="%.1f")
            internal_marks = st.number_input("Internal Assessment Marks (%) *", min_value=0.0, max_value=100.0, value=70.0, step=0.5, format="%.1f")
            extracurricular = st.selectbox("Extracurricular Participation", options=preprocessing.EXTRACURRICULAR_OPTIONS, index=1)

        st.markdown("<hr style='margin: 1rem 0;'>", unsafe_allow_html=True)
        auto_predict = st.checkbox("Generate initial Random Forest prediction immediately upon saving", value=True)

        submitted = st.form_submit_button("Register & Save to Database", use_container_width=True)

        if submitted:
            # Package form data
            student_data = {
                "student_id": next_id,
                "student_name": student_name.strip(),
                "age": age,
                "gender": gender,
                "semester": semester,
                "attendance": attendance,
                "previous_marks": previous_marks,
                "study_hours": study_hours,
                "assignment_completion": assignment_completion,
                "internal_marks": internal_marks,
                "extracurricular": extracurricular
            }

            # Input validation
            is_valid, error_msg = preprocessing.validate_student_data(student_data)

            if not is_valid:
                st.error(f"Validation Error: {error_msg}")
            else:
                try:
                    # Save to SQLite
                    database.add_student(student_data)
                    st.success(f"Student record for **{student_name}** ({next_id}) successfully saved to SQLite database (`student_performance.db`).")

                    if auto_predict:
                        pred_res = model.predict_student_performance(student_data)
                        database.add_prediction({
                            "student_id": next_id,
                            "student_name": student_name.strip(),
                            "predicted_marks": pred_res["predicted_marks"],
                            "performance_level": pred_res["performance_level"],
                            "risk_level": pred_res["risk_level"],
                            "factors_summary": pred_res["explanation"]
                        })
                        st.info(f"Initial AI Prediction Generated: **{pred_res['predicted_marks']}%** ({pred_res['performance_level']}) — **{pred_res['risk_level']} Risk**.")

                except Exception as e:
                    st.error(f"Database insertion failed: {str(e)}")

    st.markdown('</div>', unsafe_allow_html=True)

