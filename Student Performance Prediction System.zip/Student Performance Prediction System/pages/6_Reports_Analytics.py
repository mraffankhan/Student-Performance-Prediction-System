"""
pages/6_Reports_Analytics.py - Reports, Analytics & Evaluation Module
Student Performance Prediction System

Provides individual student report cards, academic support rosters,
semester-wise aggregations, behavioral correlation plots, and actual Random Forest
evaluation metrics (MAE, RMSE, R², Accuracy, F1, Confusion Matrix).
"""

import streamlit as st
import plotly.graph_objects as go
import plotly.express as px
import numpy as np
import compat_pandas as pd
import database
import model
import preprocessing
import ui_components

st.set_page_config(
    page_title="Reports & Analytics | Student Performance Prediction System",
    page_icon="📈",
    layout="wide"
)

# Apply B&W theme
ui_components.apply_custom_theme()
database.init_db()
bundle = model.ensure_model_trained()
ui_components.render_sidebar()

ui_components.render_page_header(
    title="REPORTS, ANALYTICS & MODEL EVALUATION",
    subtitle="Cohort performance trends, academic support roster, individual student reports, and verified ML metrics."
)

tab_reports, tab_roster, tab_trends, tab_ml = st.tabs([
    "Individual Student Report", "Students Requiring Academic Support", "Cohort Trends & Correlations", "ML Model Evaluation"
])

# =========================================================
# TAB 1: Individual Student Report
# =========================================================
with tab_reports:
    st.markdown("### Generate Student Academic Performance Report")
    students_df = database.get_all_students()

    if not students_df.empty:
        records = students_df.to_dict(orient="records")
        opts = {f"{r['student_id']} - {r['student_name']} ({r['semester']})": r for r in records}
        chosen = st.selectbox("Select Student to Generate Report:", options=list(opts.keys()), key="rep_sel")
        target_stu = opts[chosen]

        # Get latest prediction or run on the fly
        pred_res = model.predict_student_performance(target_stu)

        rep_col1, rep_col2 = st.columns([2, 1])

        with rep_col1:
            st.markdown(
                f"""
                <div class="bw-card">
                    <div style="display: flex; justify-content: space-between; align-items: center; border-bottom: 1px solid #e2e8f0; padding-bottom: 0.75rem; margin-bottom: 1rem;">
                        <div>
                            <h2 style="margin: 0; font-size: 1.4rem; color: #000;">{target_stu['student_name']}</h2>
                            <span style="font-family: monospace; font-size: 0.85rem; color: #64748b;">ID: {target_stu['student_id']} | {target_stu['semester']}</span>
                        </div>
                        <div>
                            {ui_components.get_risk_badge_html(pred_res['risk_level'])}
                        </div>
                    </div>
                    
                    <div style="display: grid; grid-template-columns: 1fr 1fr; gap: 1rem; font-size: 0.9rem;">
                        <div>
                            <strong>Age:</strong> {target_stu['age']} yrs<br>
                            <strong>Gender:</strong> {target_stu.get('gender', 'N/A')}<br>
                            <strong>Extracurricular:</strong> {target_stu.get('extracurricular', 'No')}<br>
                            <strong>Registered Date:</strong> {target_stu.get('created_at', 'N/A')}
                        </div>
                        <div>
                            <strong>Attendance Rate:</strong> {target_stu['attendance']}%<br>
                            <strong>Prior Exam Marks:</strong> {target_stu['previous_marks']}%<br>
                            <strong>Daily Study Hours:</strong> {target_stu['study_hours']} hrs/day<br>
                            <strong>Internal Assessment:</strong> {target_stu['internal_marks']}%<br>
                            <strong>Assignment Completion:</strong> {target_stu['assignment_completion']}%
                        </div>
                    </div>

                    <div style="margin-top: 1.25rem; padding: 0.85rem; background: #fafafa; border: 1px solid #000; border-radius: 4px;">
                        <div style="font-size: 0.75rem; text-transform: uppercase; font-weight: 700; color: #000;">AI Academic Advisory</div>
                        <div style="font-size: 0.88rem; color: #222; margin-top: 0.35rem; line-height: 1.5;">{pred_res['explanation']}</div>
                    </div>
                </div>
                """,
                unsafe_allow_html=True
            )

        with rep_col2:
            st.markdown(
                f"""
                <div class="prediction-box" style="text-align: center; margin-top: 0;">
                    <div style="font-size: 0.8rem; font-weight: 700; color: #64748b; text-transform: uppercase;">Predicted Marks</div>
                    <div class="prediction-score">{pred_res['predicted_marks']}%</div>
                    <div class="prediction-tier">{pred_res['performance_level']}</div>
                    <div style="margin-top: 1rem; font-size: 0.82rem; color: #555;">
                        Status: Evaluated via Random Forest Model
                    </div>
                </div>
                """,
                unsafe_allow_html=True
            )

        # Download Report CSV
        report_row = [{
            "student_id": target_stu["student_id"],
            "student_name": target_stu["student_name"],
            "semester": target_stu["semester"],
            "attendance": target_stu["attendance"],
            "previous_marks": target_stu["previous_marks"],
            "study_hours": target_stu["study_hours"],
            "internal_marks": target_stu["internal_marks"],
            "assignment_completion": target_stu["assignment_completion"],
            "predicted_marks": pred_res["predicted_marks"],
            "performance_level": pred_res["performance_level"],
            "risk_level": pred_res["risk_level"],
            "explanation": pred_res["explanation"]
        }]
        rep_csv = pd.DataFrame(report_row).to_csv(index=False)

        st.download_button(
            label=f"⬇️ Download Official Academic Report for {target_stu['student_name']} (CSV)",
            data=rep_csv,
            file_name=f"Report_{target_stu['student_id']}.csv",
            mime="text/csv"
        )
    else:
        st.info("No registered students available to generate reports.")


# =========================================================
# TAB 2: Students Requiring Academic Support
# =========================================================
with tab_roster:
    st.markdown("### Early Intervention Roster: Students Requiring Support")
    st.caption("Identifies students categorized in High or Medium Risk tiers based on attendance deficits, low previous scores, or study hour deficits.")

    students_df = database.get_all_students()
    if not students_df.empty:
        # Run predictions for cohort
        support_list = []
        for s in students_df.to_dict(orient="records"):
            res = model.predict_student_performance(s)
            if res["risk_level"] in ["High", "Medium"]:
                support_list.append({
                    "Student ID": s["student_id"],
                    "Name": s["student_name"],
                    "Semester": s["semester"],
                    "Attendance (%)": s["attendance"],
                    "Previous Marks (%)": s["previous_marks"],
                    "Study Hours": s["study_hours"],
                    "Predicted Marks (%)": res["predicted_marks"],
                    "Performance Tier": res["performance_level"],
                    "Risk Level": res["risk_level"]
                })

        support_df = pd.DataFrame(support_list)
        if not support_df.empty:
            st.markdown(f"**Found {len(support_df)} student(s) requiring academic advising or intervention:**")
            ui_components.render_table(support_df)

            csv_support = support_df.to_csv(index=False)
            st.download_button(
                label="⬇️ Export Academic Support Roster (CSV)",
                data=csv_support,
                file_name="academic_support_roster.csv",
                mime="text/csv"
            )
        else:
            st.success("All registered students are currently in the Low Risk category.")
    else:
        st.info("No student records found in database.")


# =========================================================
# TAB 3: Cohort Trends & Correlation Analysis
# =========================================================
with tab_trends:
    st.markdown("### Academic Cohort Visualizations")
    students_df = database.get_all_students()

    if not students_df.empty:
        trend_col1, trend_col2 = st.columns(2)

        with trend_col1:
            st.markdown("#### Average Marks by Semester")
            sem_marks = {}
            for s in students_df.to_dict(orient="records"):
                sem = s["semester"]
                sem_marks.setdefault(sem, []).append(float(s["previous_marks"]))

            sem_avg = [{"Semester": k, "Avg Marks": round(float(np.mean(v)), 1)} for k, v in sem_marks.items()]
            sem_avg.sort(key=lambda x: x["Semester"])
            sem_df = pd.DataFrame(sem_avg)

            fig_sem = ui_components.create_monochrome_bar_chart(
                df=sem_df,
                x_col="Semester",
                y_col="Avg Marks",
                title="Average Marks by Semester",
                x_label="Semester",
                y_label="Marks (%)"
            )
            st.plotly_chart(fig_sem, use_container_width=True)

        with trend_col2:
            st.markdown("#### Attendance vs. Previous Examination Marks")
            att_vals = [float(s["attendance"]) for s in students_df.to_dict(orient="records")]
            marks_vals = [float(s["previous_marks"]) for s in students_df.to_dict(orient="records")]
            names = [s["student_name"] for s in students_df.to_dict(orient="records")]

            fig_scatter = go.Figure(data=go.Scatter(
                x=att_vals,
                y=marks_vals,
                mode='markers',
                text=names,
                marker=dict(
                    color='#111111',
                    size=9,
                    line=dict(color='#000000', width=1)
                )
            ))
            fig_scatter.update_layout(
                title=dict(text="Attendance vs. Marks Scatter Plot", font=dict(family="Inter", size=14)),
                xaxis=dict(title="Attendance (%)", showgrid=True, gridcolor="#f1f5f9"),
                yaxis=dict(title="Previous Marks (%)", showgrid=True, gridcolor="#f1f5f9"),
                plot_bgcolor="#ffffff",
                paper_bgcolor="#ffffff",
                height=340,
                margin=dict(l=40, r=20, t=50, b=40)
            )
            st.plotly_chart(fig_scatter, use_container_width=True)

        st.markdown("<br>", unsafe_allow_html=True)

        # ---------------------------------------------------------
        # Inter-Grade Collinearity & Feature Correlation Heatmap
        # ---------------------------------------------------------
        st.markdown("#### Inter-Grade Collinearity Heatmap (Feature Correlations)")
        st.caption("Visualizes Pearson correlation coefficients between academic scores and behavioral features. High positive values indicate collinearity between evaluation metrics.")

        feature_cols = ["attendance", "previous_marks", "study_hours", "assignment_completion", "internal_marks"]
        feature_labels = ["Attendance", "Previous Marks", "Study Hours", "Assignments", "Internal Marks"]

        raw_records = students_df.to_dict(orient="records")
        n_feat = len(feature_cols)
        data_matrix = np.zeros((len(raw_records), n_feat))
        for r_i, rec in enumerate(raw_records):
            for c_i, col in enumerate(feature_cols):
                data_matrix[r_i, c_i] = float(rec.get(col, 0.0))

        # Compute Pearson correlation matrix
        corr_matrix = np.corrcoef(data_matrix, rowvar=False)
        corr_rounded = np.round(corr_matrix, 2)

        # Render monochrome correlation heatmap
        fig_corr = go.Figure(data=go.Heatmap(
            z=corr_rounded,
            x=feature_labels,
            y=feature_labels,
            colorscale=[[0, "#ffffff"], [0.5, "#888888"], [1, "#000000"]],
            zmin=-1.0,
            zmax=1.0,
            text=corr_rounded,
            texttemplate="%{text}",
            textfont={"size": 13, "color": "auto"},
            colorbar=dict(title="r", tickfont=dict(family="Inter"))
        ))
        fig_corr.update_layout(
            title=dict(text="Inter-Grade Collinearity Matrix (Pearson Correlation)", font=dict(family="Inter", size=14)),
            height=420,
            margin=dict(l=80, r=40, t=50, b=50)
        )
        st.plotly_chart(fig_corr, use_container_width=True)

        st.markdown(
            """
            <div style="background: #fafafa; border: 1px solid #000; border-radius: 4px; padding: 0.85rem 1rem; font-size: 0.85rem; color: #222; margin-top: 0.5rem;">
                <strong>Academic Insight on Collinearity:</strong> High correlation ($r > 0.70$) between <em>Previous Marks</em>, <em>Internal Marks</em>, and <em>Assignments</em> demonstrates strong inter-grade collinearity. While traditional linear regression suffers from variance inflation when predictors are collinear, our <strong>Random Forest model</strong> is naturally resistant to multicollinearity because it randomly samples feature subsets at each decision split.
            </div>
            """,
            unsafe_allow_html=True
        )

        st.markdown("<br>", unsafe_allow_html=True)
        st.markdown("#### Study Hours vs. Performance")
        study_vals = [float(s["study_hours"]) for s in students_df.to_dict(orient="records")]

        fig_study = go.Figure(data=go.Scatter(
            x=study_vals,
            y=marks_vals,
            mode='markers',
            text=names,
            marker=dict(
                color='#333333',
                size=9,
                line=dict(color='#000000', width=1)
            )
        ))
        fig_study.update_layout(
            title=dict(text="Daily Study Hours vs. Examination Marks", font=dict(family="Inter", size=14)),
            xaxis=dict(title="Daily Study Hours", showgrid=True, gridcolor="#f1f5f9"),
            yaxis=dict(title="Marks (%)", showgrid=True, gridcolor="#f1f5f9"),
            plot_bgcolor="#ffffff",
            paper_bgcolor="#ffffff",
            height=320,
            margin=dict(l=40, r=20, t=50, b=40)
        )
        st.plotly_chart(fig_study, use_container_width=True)


# =========================================================
# TAB 4: ML Model Evaluation Metrics
# =========================================================
with tab_ml:
    st.markdown("### Random Forest Model Evaluation Report")
    st.caption("Actual metrics computed on an unseen 20% holdout test set during model training. Metrics are not fabricated or assumed.")

    ml_metrics = bundle.get("metrics", {})
    reg_metrics = ml_metrics.get("regression", {})
    clf_metrics = ml_metrics.get("classification", {})

    st.markdown("#### 1. Regression Metrics (Target: Expected Marks 0-100)")
    r_col1, r_col2, r_col3 = st.columns(3)
    with r_col1:
        st.markdown(ui_components.metric_card(
            title="Mean Absolute Error (MAE)",
            value=f"{reg_metrics.get('mae', 'N/A')}",
            subtitle="Average absolute point error"
        ), unsafe_allow_html=True)
    with r_col2:
        st.markdown(ui_components.metric_card(
            title="Root Mean Squared Error (RMSE)",
            value=f"{reg_metrics.get('rmse', 'N/A')}",
            subtitle="Standard error of predictions"
        ), unsafe_allow_html=True)
    with r_col3:
        st.markdown(ui_components.metric_card(
            title="R² Goodness of Fit",
            value=f"{reg_metrics.get('r2', 'N/A')}",
            subtitle="Variance explained by model"
        ), unsafe_allow_html=True)

    st.markdown("<br>", unsafe_allow_html=True)
    st.markdown("#### 2. Classification Metrics (Target: Performance Tier)")
    c_col1, c_col2, c_col3, c_col4 = st.columns(4)
    with c_col1:
        st.markdown(ui_components.metric_card(
            title="Accuracy",
            value=f"{clf_metrics.get('accuracy', 'N/A')}",
            subtitle="Overall correct tier classifications"
        ), unsafe_allow_html=True)
    with c_col2:
        st.markdown(ui_components.metric_card(
            title="Weighted Precision",
            value=f"{clf_metrics.get('precision', 'N/A')}",
            subtitle="Precision across all classes"
        ), unsafe_allow_html=True)
    with c_col3:
        st.markdown(ui_components.metric_card(
            title="Weighted Recall",
            value=f"{clf_metrics.get('recall', 'N/A')}",
            subtitle="Recall across all classes"
        ), unsafe_allow_html=True)
    with c_col4:
        st.markdown(ui_components.metric_card(
            title="Weighted F1-Score",
            value=f"{clf_metrics.get('f1_score', 'N/A')}",
            subtitle="Harmonic mean of precision & recall"
        ), unsafe_allow_html=True)

    # Confusion Matrix Visualization
    st.markdown("<br>", unsafe_allow_html=True)
    st.markdown("#### 3. Confusion Matrix")
    cm_data = clf_metrics.get("confusion_matrix", [])
    classes = clf_metrics.get("classes", ["Needs Improvement", "Average", "Good", "Excellent"])

    if cm_data:
        cm_arr = np.array(cm_data)
        fig_cm = go.Figure(data=go.Heatmap(
            z=cm_arr,
            x=classes,
            y=classes,
            colorscale=[[0, "#ffffff"], [0.5, "#888888"], [1, "#000000"]],
            text=cm_arr,
            texttemplate="%{text}",
            textfont={"size": 14, "color": "auto"},
            showscale=False
        ))
        fig_cm.update_layout(
            title=dict(text="Confusion Matrix (Predicted vs Actual Tiers)", font=dict(family="Inter", size=14)),
            xaxis=dict(title="Predicted Performance Tier"),
            yaxis=dict(title="Actual Performance Tier"),
            height=360,
            margin=dict(l=40, r=20, t=50, b=40)
        )
        st.plotly_chart(fig_cm, use_container_width=True)

    # Retrain button
    st.markdown("<hr>", unsafe_allow_html=True)
    if st.button("🔄 Retrain Random Forest Model with Latest Data"):
        with st.spinner("Retraining Random Forest Regressor & Classifier..."):
            new_bundle = model.train_model()
            st.success(f"Model successfully retrained at {new_bundle['trained_at']}! Updated R²: {new_bundle['metrics']['regression']['r2']}, Accuracy: {new_bundle['metrics']['classification']['accuracy']}.")
            st.rerun()

