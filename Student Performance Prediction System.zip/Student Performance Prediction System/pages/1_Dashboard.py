"""
pages/1_Dashboard.py - Cohort Analytics Dashboard
Student Performance Prediction System

Displays cohort KPI cards, performance distribution, attendance histogram,
risk tier categorization, and recent prediction activity.
"""

import streamlit as st
import compat_pandas as pd
import database
import model
import data_generator
import ui_components

st.set_page_config(
    page_title="Dashboard | Student Performance Prediction System",
    page_icon="📊",
    layout="wide"
)

# Initialize and apply B&W styling
ui_components.apply_custom_theme()
database.init_db()
data_generator.ensure_dataset_exists()
data_generator.seed_initial_database_if_empty()
model.ensure_model_trained()

ui_components.render_sidebar()

ui_components.render_page_header(
    title="COHORT ANALYTICS DASHBOARD",
    subtitle="Overview of registered students, predicted academic trajectories, and early warning risk indicators."
)

# Fetch latest metrics
metrics = database.get_dashboard_metrics()

# Top KPI Metric Cards Row
col1, col2, col3, col4, col5 = st.columns(5)

with col1:
    st.markdown(ui_components.metric_card(
        title="Registered Students",
        value=metrics["total_students"],
        subtitle="Active database records"
    ), unsafe_allow_html=True)

with col2:
    st.markdown(ui_components.metric_card(
        title="Total Predictions",
        value=metrics["total_predictions"],
        subtitle="Random Forest evaluations"
    ), unsafe_allow_html=True)

with col3:
    st.markdown(ui_components.metric_card(
        title="Students at Risk",
        value=metrics["high_risk_count"],
        subtitle="Immediate support advised"
    ), unsafe_allow_html=True)

with col4:
    st.markdown(ui_components.metric_card(
        title="Performing Well",
        value=metrics["well_performing_count"],
        subtitle="Excellent / Good tier"
    ), unsafe_allow_html=True)

with col5:
    st.markdown(ui_components.metric_card(
        title="Avg. Predicted Marks",
        value=f"{metrics['avg_predicted_marks']}%",
        subtitle="Cohort projected mean"
    ), unsafe_allow_html=True)

st.markdown("<br>", unsafe_allow_html=True)

# Charts Section: Monochrome Visualizations
chart_col1, chart_col2 = st.columns(2)

with chart_col1:
    st.markdown("#### Performance Level Distribution")
    perf_dist = metrics["performance_distribution"]
    if perf_dist:
        labels = list(perf_dist.keys())
        values = list(perf_dist.values())
        fig_donut = ui_components.create_monochrome_donut_chart(
            labels=labels,
            values=values,
            title="Distribution by Performance Tier"
        )
        st.plotly_chart(fig_donut, use_container_width=True)
    else:
        st.info("No prediction data available to compute performance distribution.")

with chart_col2:
    st.markdown("#### Student Attendance Distribution")
    att_data = metrics["attendance_distribution"]
    if att_data:
        fig_hist = ui_components.create_monochrome_histogram(
            data=att_data,
            title="Attendance Percentage Spread",
            x_label="Attendance (%)",
            nbins=12
        )
        st.plotly_chart(fig_hist, use_container_width=True)
    else:
        st.info("No attendance data recorded yet.")

st.markdown("<br>", unsafe_allow_html=True)

# Recent Predictions Table
st.markdown("### Recent Prediction Activity")
recent_df = metrics["recent_predictions"]

if not recent_df.empty:
    # Prepare display columns
    display_df = recent_df.copy()
    display_df.columns = ["ID", "Student ID", "Student Name", "Predicted Marks (%)", "Performance Tier", "Risk Level", "Evaluation Date"]
    
    ui_components.render_table(display_df)
else:
    st.markdown(
        """
        <div style="padding: 1.5rem; border: 1px dashed #cbd5e1; border-radius: 6px; text-align: center; color: #64748b;">
            No predictions generated yet. Navigate to <strong>Predict Performance</strong> to run an evaluation.
        </div>
        """,
        unsafe_allow_html=True
    )

