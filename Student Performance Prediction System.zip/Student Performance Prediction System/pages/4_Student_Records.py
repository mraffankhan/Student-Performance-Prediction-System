"""
pages/4_Student_Records.py - Student Records Management Module
Student Performance Prediction System

Provides a searchable, filterable registry of students, detailed profile views,
modal-style editing, confirmed record deletion, and past prediction history.
"""

import streamlit as st
import compat_pandas as pd
import database
import preprocessing
import model
import ui_components

st.set_page_config(
    page_title="Student Records | Student Performance Prediction System",
    page_icon="📋",
    layout="wide"
)

# Apply B&W theme
ui_components.apply_custom_theme()
database.init_db()
ui_components.render_sidebar()

ui_components.render_page_header(
    title="STUDENT RECORDS REGISTRY",
    subtitle="Search, filter, inspect profiles, update academic details, or manage student records in SQLite."
)

# Search & Filter Controls
ctrl_col1, ctrl_col2, ctrl_col3 = st.columns([2, 1, 1])

with ctrl_col1:
    search_query = st.text_input("🔍 Search by Student Name or ID:", placeholder="Enter name or STU-xxxx...")

with ctrl_col2:
    sem_filter = st.selectbox(
        "Filter by Semester:",
        options=["All"] + preprocessing.SEMESTER_OPTIONS
    )

with ctrl_col3:
    st.markdown("<div style='height: 28px;'></div>", unsafe_allow_html=True)
    refresh_btn = st.button("Refresh Table", use_container_width=True)

# Fetch records
students_df = database.get_all_students(
    search=search_query if search_query else None,
    semester=sem_filter if sem_filter != "All" else None
)

st.markdown(f"**Showing {len(students_df)} student record(s)**")

if not students_df.empty:
    display_df = students_df[[
        "student_id", "student_name", "semester", "attendance",
        "previous_marks", "study_hours", "internal_marks", "assignment_completion"
    ]].copy()
    display_df.columns = [
        "Student ID", "Full Name", "Semester", "Attendance (%)",
        "Previous Marks (%)", "Study Hours", "Internal Marks (%)", "Assignments (%)"
    ]
    ui_components.render_table(display_df)

    st.markdown("<hr>", unsafe_allow_html=True)
    st.markdown("### Student Detail & Action Center")

    # Select student for detailed actions
    student_records = students_df.to_dict(orient="records")
    student_choice_map = {f"{r['student_id']} — {r['student_name']}": r for r in student_records}
    selected_choice = st.selectbox("Select Student to Inspect, Edit, or Delete:", options=list(student_choice_map.keys()))
    selected_student = student_choice_map[selected_choice]

    tab_profile, tab_edit, tab_history, tab_delete = st.tabs([
        "Profile Overview", "Edit Record", "Prediction History", "Delete Student"
    ])

    with tab_profile:
        p_col1, p_col2 = st.columns(2)
        with p_col1:
            st.markdown(
                f"""
                <div class="bw-card">
                    <div class="bw-card-header">Personal Information</div>
                    <div style="font-size: 1.25rem; font-weight: 700;">{selected_student['student_name']}</div>
                    <div style="color: #64748b; font-size: 0.9rem; margin-top: 0.2rem;">ID: <strong>{selected_student['student_id']}</strong></div>
                    <div style="margin-top: 0.6rem; font-size: 0.9rem;">
                        <strong>Age:</strong> {selected_student['age']} yrs<br>
                        <strong>Gender:</strong> {selected_student.get('gender', 'N/A')}<br>
                        <strong>Semester:</strong> {selected_student['semester']}<br>
                        <strong>Extracurricular:</strong> {selected_student.get('extracurricular', 'No')}
                    </div>
                </div>
                """,
                unsafe_allow_html=True
            )
        with p_col2:
            st.markdown(
                f"""
                <div class="bw-card">
                    <div class="bw-card-header">Academic Standing</div>
                    <div style="font-size: 0.9rem; line-height: 1.8;">
                        <strong>Lecture Attendance:</strong> {selected_student['attendance']}%<br>
                        <strong>Previous Exam Marks:</strong> {selected_student['previous_marks']}%<br>
                        <strong>Daily Study Hours:</strong> {selected_student['study_hours']} hrs/day<br>
                        <strong>Internal Assessment:</strong> {selected_student['internal_marks']}%<br>
                        <strong>Assignment Completion:</strong> {selected_student['assignment_completion']}%
                    </div>
                </div>
                """,
                unsafe_allow_html=True
            )

    with tab_edit:
        st.markdown("#### Update Student Details")
        with st.form("edit_student_form"):
            e_col1, e_col2, e_col3 = st.columns(3)
            with e_col1:
                edit_name = st.text_input("Student Name", value=selected_student["student_name"])
                edit_age = st.number_input("Age", min_value=15, max_value=60, value=int(selected_student["age"]))
                edit_gender = st.selectbox("Gender", options=preprocessing.GENDER_OPTIONS, index=preprocessing.GENDER_OPTIONS.index(selected_student.get("gender", "Unspecified")) if selected_student.get("gender") in preprocessing.GENDER_OPTIONS else 1)
            with e_col2:
                cur_sem_idx = preprocessing.SEMESTER_OPTIONS.index(selected_student["semester"]) if selected_student["semester"] in preprocessing.SEMESTER_OPTIONS else 0
                edit_sem = st.selectbox("Semester", options=preprocessing.SEMESTER_OPTIONS, index=cur_sem_idx)
                edit_att = st.number_input("Attendance (%)", min_value=0.0, max_value=100.0, value=float(selected_student["attendance"]), step=0.5)
                edit_prev = st.number_input("Previous Marks (%)", min_value=0.0, max_value=100.0, value=float(selected_student["previous_marks"]), step=0.5)
            with e_col3:
                edit_study = st.number_input("Study Hours/Day", min_value=0.0, max_value=24.0, value=float(selected_student["study_hours"]), step=0.5)
                edit_assign = st.number_input("Assignment Completion (%)", min_value=0.0, max_value=100.0, value=float(selected_student["assignment_completion"]), step=0.5)
                edit_intern = st.number_input("Internal Marks (%)", min_value=0.0, max_value=100.0, value=float(selected_student["internal_marks"]), step=0.5)
                cur_extra_idx = 0 if selected_student.get("extracurricular") == "Yes" else 1
                edit_extra = st.selectbox("Extracurricular", options=preprocessing.EXTRACURRICULAR_OPTIONS, index=cur_extra_idx)

            save_changes = st.form_submit_button("Save Changes to Database", use_container_width=True)
            if save_changes:
                updated_payload = {
                    "student_name": edit_name.strip(),
                    "age": edit_age,
                    "gender": edit_gender,
                    "semester": edit_sem,
                    "attendance": edit_att,
                    "previous_marks": edit_prev,
                    "study_hours": edit_study,
                    "assignment_completion": edit_assign,
                    "internal_marks": edit_intern,
                    "extracurricular": edit_extra
                }
                is_valid, err_msg = preprocessing.validate_student_data(updated_payload)
                if not is_valid:
                    st.error(f"Validation Error: {err_msg}")
                else:
                    success = database.update_student(selected_student["student_id"], updated_payload)
                    if success:
                        st.success(f"Record for {edit_name} ({selected_student['student_id']}) successfully updated.")
                        st.rerun()
                    else:
                        st.error("Failed to update student record.")

    with tab_history:
        st.markdown(f"#### Predictions Generated for {selected_student['student_name']}")
        stu_preds = database.get_predictions(student_id=selected_student["student_id"])
        if not stu_preds.empty:
            hist_display = stu_preds[["id", "predicted_marks", "performance_level", "risk_level", "prediction_date", "factors_summary"]].copy()
            hist_display.columns = ["ID", "Predicted Marks (%)", "Performance Tier", "Risk Level", "Date Evaluated", "Summary"]
            ui_components.render_table(hist_display)
        else:
            st.info("No prediction history recorded for this student yet.")

    with tab_delete:
        st.markdown("#### Delete Student Record")
        st.warning(f"⚠️ Are you sure you want to permanently delete **{selected_student['student_name']}** ({selected_student['student_id']})? All associated predictions will also be deleted from SQLite.")
        
        del_confirm = st.checkbox("I confirm that I wish to permanently delete this student record.")
        if st.button("Permanently Delete Record", disabled=not del_confirm, type="primary"):
            deleted = database.delete_student(selected_student["student_id"])
            if deleted:
                st.success(f"Student {selected_student['student_id']} deleted successfully.")
                st.rerun()
            else:
                st.error("Deletion failed.")

else:
    st.info("No student records match the search or filter criteria.")

