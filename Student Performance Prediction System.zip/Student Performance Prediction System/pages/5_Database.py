"""
pages/5_Database.py - Integrated SQLite Database Viewer
Student Performance Prediction System

Provides in-app introspection of the local SQLite database (student_performance.db):
metadata, table selectors, row counts, schema viewer, interactive dataframe explorer,
and a read-only SQL query testing console.
"""

import os
import streamlit as st
import compat_pandas as pd
import database
import ui_components

st.set_page_config(
    page_title="Database Viewer | Student Performance Prediction System",
    page_icon="🗄️",
    layout="wide"
)

# Apply B&W theme
ui_components.apply_custom_theme()
database.init_db()
ui_components.render_sidebar()

ui_components.render_page_header(
    title="INTEGRATED DATABASE VIEWER",
    subtitle="Direct introspection of local SQLite tables, schemas, and live database records."
)

# Database metadata
db_info = database.get_database_info()

meta_col1, meta_col2, meta_col3, meta_col4 = st.columns(4)

with meta_col1:
    st.markdown(ui_components.metric_card(
        title="Database File",
        value=db_info["name"],
        subtitle="Local SQLite 3 format"
    ), unsafe_allow_html=True)

with meta_col2:
    st.markdown(ui_components.metric_card(
        title="Database Size",
        value=f"{db_info['size_kb']} KB",
        subtitle=f"Last modified: {db_info['last_modified']}"
    ), unsafe_allow_html=True)

with meta_col3:
    st.markdown(ui_components.metric_card(
        title="Students Table",
        value=db_info["table_counts"].get("students", 0),
        subtitle="Total student records"
    ), unsafe_allow_html=True)

with meta_col4:
    st.markdown(ui_components.metric_card(
        title="Predictions Table",
        value=db_info["table_counts"].get("predictions", 0),
        subtitle="Total prediction logs"
    ), unsafe_allow_html=True)

st.markdown("<br>", unsafe_allow_html=True)

# Database file absolute path banner
st.markdown(
    f"""
    <div style="background: #ffffff; border: 1px solid #e2e8f0; border-radius: 6px; padding: 0.85rem 1.15rem; font-family: monospace; font-size: 0.85rem; color: #1e293b;">
        <strong>SQLite File Location:</strong> {db_info['path']}
    </div>
    """,
    unsafe_allow_html=True
)

st.markdown("<br>", unsafe_allow_html=True)

# Table selector & refresh button
sel_col1, sel_col2 = st.columns([3, 1])

with sel_col1:
    available_tables = db_info["tables"]
    selected_table = st.selectbox(
        "Select Database Table to Inspect:",
        options=available_tables,
        index=0 if available_tables else 0
    )

with sel_col2:
    st.markdown("<div style='height: 28px;'></div>", unsafe_allow_html=True)
    if st.button("🔄 Refresh Database Data", use_container_width=True):
        st.rerun()

if selected_table:
    total_rows = database.get_table_row_count(selected_table)
    st.markdown(f"### Table: `{selected_table}` ({total_rows} records)")

    # Data Tabs: Live Data vs Table Schema
    tab_data, tab_schema, tab_query, tab_manage = st.tabs([
        "Live Table Data", "Table Schema & Column Info", "Read-Only SQL Console", "Maintenance & Seeding"
    ])

    with tab_data:
        table_df = database.get_table_data(selected_table)
        if not table_df.empty:
            ui_components.render_table(table_df)
            
            # Export CSV
            csv_data = table_df.to_csv(index=False)
            st.download_button(
                label=f"⬇️ Export `{selected_table}` as CSV",
                data=csv_data,
                file_name=f"{selected_table}_export.csv",
                mime="text/csv"
            )
        else:
            st.info(f"Table `{selected_table}` is currently empty.")

    with tab_schema:
        st.markdown(f"#### Column Definitions & Data Types for `{selected_table}`")
        schema_df = database.get_table_schema(selected_table)
        schema_df.columns = ["Column ID", "Column Name", "Data Type", "Not Null?", "Default Value", "Primary Key?"]
        ui_components.render_table(schema_df)

    with tab_query:
        st.markdown("#### Direct Read-Only SQL Query Console")
        st.caption("Demonstration tool for examiners: run safe SELECT or PRAGMA queries directly against SQLite.")

        default_query = f"SELECT * FROM {selected_table} LIMIT 10;"
        user_query = st.text_area("SQL Statement:", value=default_query, height=80)

        if st.button("Execute Query"):
            success, result = database.execute_raw_query(user_query)
            if success:
                st.success(f"Query returned {len(result)} row(s).")
                ui_components.render_table(result)
            else:
                st.error(f"SQL Error: {result}")

    with tab_manage:
        st.markdown("#### Database Maintenance & Demo Utilities")
        st.caption("Useful for project presentations and resetting data to a known state.")

        m_col1, m_col2 = st.columns(2)

        with m_col1:
            st.markdown(
                """
                <div class="bw-card">
                    <h4 style="margin: 0 0 0.5rem 0;">Re-seed Sample Data</h4>
                    <p style="font-size: 0.85rem; color: #555;">
                        Clears the database and seeds 24 diverse student records with full prediction history across Semesters 1 to 6.
                    </p>
                </div>
                """,
                unsafe_allow_html=True
            )
            if st.button("🌱 Reset & Re-seed Sample Database"):
                with database.get_connection() as conn:
                    conn.execute("DELETE FROM predictions;")
                    conn.execute("DELETE FROM students;")
                    conn.commit()
                import data_generator
                data_generator.seed_initial_database_if_empty()
                st.success("Database cleanly re-seeded with 24 student records and predictions!")
                st.rerun()

        with m_col2:
            st.markdown(
                """
                <div class="bw-card">
                    <h4 style="margin: 0 0 0.5rem 0;">Wipe All Data</h4>
                    <p style="font-size: 0.85rem; color: #555;">
                        Empties both the <code>students</code> and <code>predictions</code> tables for testing empty states.
                    </p>
                </div>
                """,
                unsafe_allow_html=True
            )
            confirm_wipe = st.checkbox("Confirm database wipe", key="chk_wipe")
            if st.button("🗑️ Empty All Tables", disabled=not confirm_wipe, type="primary"):
                with database.get_connection() as conn:
                    conn.execute("DELETE FROM predictions;")
                    conn.execute("DELETE FROM students;")
                    conn.commit()
                st.warning("All records from students and predictions have been deleted.")
                st.rerun()

