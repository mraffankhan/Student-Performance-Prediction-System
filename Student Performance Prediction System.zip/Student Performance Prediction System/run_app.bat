@echo off
title Student Performance Prediction System
echo ========================================================
echo Launching Student Performance Prediction System...
echo ========================================================
cd /d "%~dp0"
python -m streamlit run app.py
pause

