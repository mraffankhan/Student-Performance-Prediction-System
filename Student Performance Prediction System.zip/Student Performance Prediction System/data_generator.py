"""
data_generator.py - Synthetic Academic Data Generator
Student Performance Prediction System

Generates a realistic, clearly labeled synthetic dataset for demonstration
and model training. Keeps dataset generation cleanly separated from prediction logic.
"""

import os
import random
import numpy as np
import compat_pandas as pd
from typing import Optional
from preprocessing import (
    SEMESTER_OPTIONS,
    GENDER_OPTIONS,
    EXTRACURRICULAR_OPTIONS,
    categorize_performance,
    determine_risk_level
)

DATA_DIR = os.path.join(os.path.dirname(os.path.abspath(__file__)), "data")
DATA_FILE = os.path.join(DATA_DIR, "synthetic_student_data.csv")

# Fictional names for realistic demonstration
FIRST_NAMES = [
    "Aarav", "Aditi", "Rohan", "Ananya", "Vikram", "Pooja", "Rahul", "Sneha",
    "Kavita", "Amit", "Priya", "Arjun", "Neha", "Karan", "Divya", "Siddharth",
    "Meera", "Varun", "Rhea", "Manish", "Tanvi", "Nikhil", "Simran", "Deepak",
    "Ishaan", "Tara", "Akash", "Bhavna", "Gaurav", "Shreya", "Sameer", "Preeti"
]

LAST_NAMES = [
    "Sharma", "Verma", "Gupta", "Patel", "Singh", "Kumar", "Iyer", "Nair",
    "Reddy", "Mehta", "Chopra", "Joshi", "Deshmukh", "Bose", "Kulkarni", "Saxena"
]


def generate_synthetic_dataset(n_samples: int = 1200, random_state: int = 42) -> pd.DataFrame:
    """
    Generates a synthetic academic dataset with realistic educational correlations.
    
    IMPORTANT NOTICE:
    This dataset is strictly synthetic and generated algorithmically for internship
    and academic demonstration purposes. It does not represent actual college students.
    """
    np.random.seed(random_state)
    random.seed(random_state)

    records = []
    for i in range(1, n_samples + 1):
        # Academic & behavioral indicators
        gender = random.choice(["Female", "Male", "Other"])
        first = random.choice(FIRST_NAMES)
        last = random.choice(LAST_NAMES)
        student_name = f"{first} {last}"
        
        semester = random.choice(SEMESTER_OPTIONS)
        sem_num = int(semester.split(" ")[1])
        age = int(np.random.choice([18, 19, 20, 21, 22, 23], p=[0.15, 0.30, 0.30, 0.15, 0.07, 0.03]))
        
        # Student behavioral archetypes:
        # 1: Diligent / High Performer (35%)
        # 2: Average / Consistent (40%)
        # 3: Struggling / At Risk (25%)
        archetype = np.random.choice(["high", "avg", "struggling"], p=[0.35, 0.40, 0.25])
        
        if archetype == "high":
            attendance = np.clip(np.random.normal(88, 6), 75, 100)
            previous_marks = np.clip(np.random.normal(82, 7), 70, 99)
            study_hours = np.clip(np.random.normal(6.0, 1.2), 3.5, 10.0)
            assignment_completion = np.clip(np.random.normal(92, 5), 80, 100)
            internal_marks = np.clip(np.random.normal(85, 6), 72, 98)
            extracurricular = np.random.choice(["Yes", "No"], p=[0.65, 0.35])
        elif archetype == "avg":
            attendance = np.clip(np.random.normal(74, 7), 60, 88)
            previous_marks = np.clip(np.random.normal(62, 6), 50, 75)
            study_hours = np.clip(np.random.normal(3.8, 1.0), 2.0, 6.0)
            assignment_completion = np.clip(np.random.normal(72, 8), 55, 88)
            internal_marks = np.clip(np.random.normal(64, 7), 50, 78)
            extracurricular = np.random.choice(["Yes", "No"], p=[0.45, 0.55])
        else:
            attendance = np.clip(np.random.normal(56, 10), 30, 72)
            previous_marks = np.clip(np.random.normal(44, 8), 25, 58)
            study_hours = np.clip(np.random.normal(2.0, 0.8), 0.5, 3.5)
            assignment_completion = np.clip(np.random.normal(48, 12), 20, 65)
            internal_marks = np.clip(np.random.normal(45, 9), 25, 58)
            extracurricular = np.random.choice(["Yes", "No"], p=[0.25, 0.75])

        # Realistic expected academic performance calculation
        # Weighted combination of prior academic indicators + small noise
        base_performance = (
            (previous_marks * 0.35) +
            (internal_marks * 0.25) +
            (attendance * 0.18) +
            (assignment_completion * 0.12) +
            ((study_hours / 10.0 * 100) * 0.10)
        )
        noise = np.random.normal(0, 2.5)
        final_marks = np.clip(base_performance + noise, 20.0, 99.5)
        final_marks = round(float(final_marks), 2)
        
        performance_tier = categorize_performance(final_marks)
        risk_tier = determine_risk_level(final_marks, attendance, previous_marks)

        records.append({
            "student_id": f"STU-{1000 + i:04d}",
            "student_name": student_name,
            "age": age,
            "gender": gender,
            "semester": semester,
            "attendance": round(float(attendance), 1),
            "previous_marks": round(float(previous_marks), 1),
            "study_hours": round(float(study_hours), 1),
            "assignment_completion": round(float(assignment_completion), 1),
            "internal_marks": round(float(internal_marks), 1),
            "extracurricular": extracurricular,
            "expected_marks": final_marks,
            "performance_level": performance_tier,
            "risk_level": risk_tier,
            "is_synthetic": 1
        })

    df = pd.DataFrame(records)
    return df


def ensure_dataset_exists() -> str:
    """Ensures that the synthetic training dataset is generated and saved locally."""
    os.makedirs(DATA_DIR, exist_ok=True)
    if not os.path.exists(DATA_FILE):
        df = generate_synthetic_dataset(n_samples=1200)
        df.to_csv(DATA_FILE, index=False)
    return DATA_FILE


def seed_initial_database_if_empty():
    """
    Seeds initial demonstration student records in SQLite if empty,
    so that first-time users can immediately explore all features.
    """
    import database
    database.init_db()
    with database.get_connection() as conn:
        cursor = conn.cursor()
        cursor.execute("SELECT COUNT(*) as count FROM students;")
        count = cursor.fetchone()["count"]

    if count == 0:
        # Generate 24 diverse seed students
        sample_df = generate_synthetic_dataset(n_samples=24, random_state=101)
        import model
        # Ensure model is trained
        model.ensure_model_trained()

        for _, row in sample_df.iterrows():
            stu_data = {
                "student_id": row["student_id"],
                "student_name": row["student_name"],
                "age": row["age"],
                "gender": row["gender"],
                "semester": row["semester"],
                "attendance": row["attendance"],
                "previous_marks": row["previous_marks"],
                "study_hours": row["study_hours"],
                "assignment_completion": row["assignment_completion"],
                "internal_marks": row["internal_marks"],
                "extracurricular": row["extracurricular"]
            }
            database.add_student(stu_data)

            # Generate and record initial prediction
            pred_res = model.predict_student_performance(stu_data)
            database.add_prediction({
                "student_id": row["student_id"],
                "student_name": row["student_name"],
                "predicted_marks": pred_res["predicted_marks"],
                "performance_level": pred_res["performance_level"],
                "risk_level": pred_res["risk_level"],
                "prediction_date": pd.Timestamp.now().strftime("%Y-%m-%d %H:%M:%S"),
                "factors_summary": pred_res.get("explanation", "")
            })
