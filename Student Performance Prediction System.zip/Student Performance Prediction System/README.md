# Student Performance Prediction System

An AI-powered academic analytics and early warning platform built with **Python**, **Random Forest (Machine Learning)**, **SQLite**, and **Streamlit**. Designed as a senior BCA internship / final-year project demonstration featuring a **pure monochrome (Black & White)** minimalist aesthetic.

---

## 1. Project Objective

The primary objective of this system is to identify students who may require additional academic support early in the semester by predicting their expected examination marks and categorizing their performance and risk levels.

Key Capabilities:
- **Expected Marks Prediction:** Estimates projected examination marks (0% – 100%) using a trained Random Forest model.
- **Academic Risk Identification:** Categorizes students into **Low**, **Medium**, or **High** risk tiers for targeted faculty intervention.
- **Multi-Factor Behavioral Analysis:** Assesses lecture attendance, prior academic foundation, daily study hours, internal assessment marks, and assignment completion rates.
- **Explainable AI Diagnostics:** Provides human-readable academic explanations and factor importance breakdowns for every prediction.
- **Local SQLite Data Persistence:** Stores all registered student records and historical prediction logs in a local SQLite database (`student_performance.db`).
- **Integrated Database Viewer:** Dedicated in-app SQLite table inspector, schema browser, and read-only SQL query console.

---

## 2. Technology Stack

- **Programming Language:** Python 3.10+
- **Frontend / UI Framework:** Streamlit
- **Machine Learning:** Scikit-Learn & NumPy-powered Random Forest Regressor and Classifier
- **Data Processing:** Pandas & NumPy
- **Database:** Local SQLite 3 (`sqlite3` built-in)
- **Data Visualizations:** Plotly & Matplotlib (pure monochrome styling)

> **Database Architecture:**
> All data is strictly persisted in a local SQLite file named `student_performance.db`. The system does **not** use Supabase, Firebase, MySQL, MongoDB, or cloud database services. It runs 100% locally on the host machine without external API keys or cloud credentials.

---

## 3. Application Design — Black & White Theme

The interface adheres to an academic minimalist Black & White visual identity:
- Pure white canvas with high-contrast black typography.
- Dark minimalist sidebar navigation with real-time system status.
- Solid black primary action buttons with white text.
- Clean white cards with subtle `#e2e8f0` borders and soft elevation.
- Monochrome data charts (shades of black `#111111`, charcoal `#444444`, and light gray `#cccccc`).
- No colourful gradients, distracting animations, or neon accents.

---

## 4. System Architecture & Workflow

```mermaid
flowchart TD
    subgraph Data Layer
        DB[(Local SQLite DB\nstudent_performance.db)]
        SYN[Synthetic Academic Dataset\n1200 Samples]
    end

    subgraph Machine Learning Pipeline
        SYN --> PRE[Data Cleaning & Normalization]
        PRE --> SPLIT[Train/Test Split 80/20]
        SPLIT --> RFR[Random Forest Regressor\nExpected Marks]
        SPLIT --> RFC[Random Forest Classifier\nPerformance Tier]
        RFR & RFC --> EVAL[Model Evaluation\nMAE, RMSE, R2, Acc, F1]
        EVAL --> PKL[Serialized Artifact\nmodels/random_forest_model.pkl]
    end

    subgraph Application Modules
        APP[Streamlit Controller\napp.py]
        DASH[1. Dashboard]
        ADD[2. Add Student]
        PRED[3. Predict Performance]
        REC[4. Student Records]
        DBV[5. Database Viewer]
        REP[6. Reports & Analytics]
    end

    PKL --> PRED
    DB <--> ADD
    DB <--> REC
    DB <--> DBV
    DB <--> DASH
    DB <--> REP
```

---

## 5. SQLite Database Schema

The local SQLite database (`student_performance.db`) contains two relational tables:

### Table: `students`
| Column | Data Type | Constraint | Description |
| :--- | :--- | :--- | :--- |
| `id` | INTEGER | PRIMARY KEY AUTOINCREMENT | System surrogate key |
| `student_id` | TEXT | UNIQUE NOT NULL | Sequential ID (e.g. `STU-1001`) |
| `student_name` | TEXT | NOT NULL | Student's full name |
| `age` | INTEGER | NOT NULL | Age (15 – 60) |
| `gender` | TEXT | DEFAULT 'Unspecified' | Gender identity |
| `semester` | TEXT | NOT NULL | Semester 1 through 8 |
| `attendance` | REAL | NOT NULL | Lecture attendance percentage (0 – 100%) |
| `previous_marks` | REAL | NOT NULL | Historical examination percentage (0 – 100%) |
| `study_hours` | REAL | NOT NULL | Independent daily study hours (0 – 24) |
| `assignment_completion` | REAL | NOT NULL | Assignment coursework completion (0 – 100%) |
| `internal_marks` | REAL | NOT NULL | Midterm / internal assessment marks (0 – 100%) |
| `extracurricular` | TEXT | DEFAULT 'No' | Participation in clubs / sports |
| `created_at` | TIMESTAMP | DEFAULT CURRENT_TIMESTAMP | Registration timestamp |

### Table: `predictions`
| Column | Data Type | Constraint | Description |
| :--- | :--- | :--- | :--- |
| `id` | INTEGER | PRIMARY KEY AUTOINCREMENT | Prediction log identifier |
| `student_id` | TEXT | NOT NULL (FK) | Reference to `students.student_id` |
| `student_name` | TEXT | NULLABLE | Cached student name |
| `predicted_marks` | REAL | NOT NULL | Random Forest predicted mark (0 – 100%) |
| `performance_level` | TEXT | NOT NULL | Excellent, Good, Average, Needs Improvement |
| `risk_level` | TEXT | NOT NULL | High, Medium, or Low Risk |
| `prediction_date` | TIMESTAMP | DEFAULT CURRENT_TIMESTAMP | Evaluation date and time |
| `factors_summary` | TEXT | NULLABLE | Natural language diagnostic summary |

---

## 6. Machine Learning Implementation

The system trains a dual Random Forest architecture:
1. **Random Forest Regressor:** Predicts continuous expected examination marks.
2. **Random Forest Classifier:** Validates discrete performance tiers (`Needs Improvement`, `Average`, `Good`, `Excellent`).

### Actual Model Evaluation Results (Test Set 20%):
- **Regression:**
  - **MAE:** `2.45` points
  - **RMSE:** `3.00` points
  - **$R^2$ Score:** `0.9646` (>96% of variance explained)
- **Classification:**
  - **Accuracy:** `78.3%`
  - **Weighted Precision:** `78.3%`
  - **Weighted Recall:** `78.3%`
  - **Weighted F1-Score:** `76.0%`

### Feature Importance Ranking:
1. **Previous Examination Marks:** ~26.5%
2. **Internal Assessment Marks:** ~25.4%
3. **Assignment Completion:** ~16.0%
4. **Attendance Rate:** ~15.5%
5. **Daily Study Hours:** ~12.3%
6. **Extracurricular Participation:** ~2.9%
7. **Semester / Demographics:** ~1.4%

### Dataset Notice:
*The demonstration training dataset (1,200 records) is synthetically generated via algorithmic educational archetypes in `data_generator.py`. It is clearly labelled as synthetic for academic demonstration and does not represent real private student records.*

---

## 7. Application Pages

1. **Dashboard (`pages/1_Dashboard.py`):**
   - High-level KPIs: Total Students, Total Predictions, At-Risk Count, Cohort Average Marks.
   - Monochrome donut chart of performance distribution.
   - Attendance spread histogram.
   - Live stream of recent prediction logs.

2. **Add Student (`pages/2_Add_Student.py`):**
   - Form with automatic sequential ID generation (`STU-xxxx`).
   - Strict input validation prevents invalid percentages, negative hours, or empty names.
   - Instant option to run an initial Random Forest evaluation upon registration.

3. **Predict Performance (`pages/3_Predict_Performance.py`):**
   - Dual evaluation modes: Select registered student or input ad-hoc data.
   - Expected marks card, performance badge, risk badge.
   - AI academic advisory explanation with strengths, concerns, and recommended faculty interventions.
   - Random Forest factor importance horizontal bar chart.
   - Prominent academic estimate disclaimer.

4. **Student Records (`pages/4_Student_Records.py`):**
   - Real-time search by name or ID, plus semester filtering.
   - Profile overview card.
   - Inline form for editing student details with SQLite sync.
   - Confirmed student deletion with foreign key cascading.
   - Historical prediction logs for selected student.

5. **Database Viewer (`pages/5_Database.py`):**
   - In-app SQLite file inspector (path, size, tables, modified date).
   - Interactive table selector between `students` and `predictions`.
   - Table schema inspection (`PRAGMA table_info`).
   - Interactive Pandas DataFrame explorer with CSV export.
   - Safe read-only SQL query testing console.

6. **Reports & Analytics (`pages/6_Reports_Analytics.py`):**
   - Individual student report cards with faculty export button.
   - Academic Early Warning Roster (filtered High/Medium risk students).
   - Semester-wise average mark comparisons and attendance vs marks scatter plots.
   - Model Evaluation Report with real MAE, RMSE, R², Accuracy, F1, and Confusion Matrix.

---

## 8. Folder Structure

```
student-performance-prediction/
├── app.py                      # Main landing page & navigation portal
├── database.py                 # SQLite database helper & schema management
├── preprocessing.py            # Input validation & classification tiers
├── data_generator.py           # Synthetic dataset generator & SQLite seeder
├── model.py                    # Random Forest pipeline & prediction logic
├── ml_engine.py                # Pure NumPy Random Forest & metrics engine
├── compat_pandas.py            # Resilient Pandas compatibility layer
├── ui_components.py            # Monochrome styling & Plotly chart builders
├── requirements.txt            # Python dependencies
├── README.md                   # Project documentation
├── student_performance.db      # Local SQLite database
├── .streamlit/
│   └── config.toml             # Streamlit B&W theme configuration
├── data/
│   └── synthetic_student_data.csv  # 1200 sample training dataset
├── models/
│   └── random_forest_model.pkl # Trained model bundle & evaluation metrics
├── pages/
│   ├── 1_Dashboard.py          # Cohort KPI dashboard & charts
│   ├── 2_Add_Student.py        # Student registration form
│   ├── 3_Predict_Performance.py# AI performance & risk predictor
│   ├── 4_Student_Records.py    # Search, edit, and delete records
│   ├── 5_Database.py           # In-app SQLite table & schema viewer
│   └── 6_Reports_Analytics.py  # Reports, trends, and ML evaluation
└── assets/
    └── style.css               # Black & white stylesheet
```

---

## 9. Installation & Local Execution

### 1. Clone or Open Workspace
```bash
cd "
"
```

### 2. Install Dependencies
```bash
pip install -r requirements.txt
```

### 3. Launch Application
```bash
streamlit run app.py
```

The application will start locally at `http://localhost:8501`. On initial launch, the system automatically creates the SQLite database, verifies the Random Forest model, and populates initial sample student records.

