# BCA Internship & Final-Year Project Viva Voce Preparation Guide
## Project: Student Performance Prediction System

This comprehensive academic guide is designed to prepare you for your final project review, viva voce, and technical demonstrations before external academic evaluators.

---

## 1. Executive Summary & Problem Definition

### Q1: What is the primary objective of this project?
**Answer:**  
The primary objective is to develop an AI-powered early warning and performance prediction platform that identifies students at academic risk before final examinations take place. By analyzing a combination of historical academic data (previous exam marks, internal assessments) and continuous behavioral factors (lecture attendance, daily study hours, assignment completion), the system provides:
1. Continuous expected mark estimates ($0\%$ to $100\%$).
2. Discrete academic performance tiers (`Excellent`, `Good`, `Average`, `Needs Improvement`).
3. Actionable academic risk categorizations (`Low`, `Medium`, `High`) with natural-language diagnostic explanations to guide faculty intervention.

### Q2: Why is early academic prediction important in higher education?
**Answer:**  
Traditional evaluation systems are reactive—faculties only realize a student is struggling after semester-end examination results are published, at which point remedial intervention is too late. This system is proactive: it detects learning deficits, critical attendance drops, or study hour deficits during the semester, enabling timely faculty mentoring, attendance recovery, and remedial classes.

---

## 2. Machine Learning Architecture & Theory

### Q3: Why did you choose Random Forest over other algorithms like Linear Regression, Decision Trees, or SVM?
**Answer:**  
Random Forest was selected for several fundamental mathematical and practical reasons:
1. **Resistance to Multicollinearity:** Academic features often exhibit strong inter-collinearity (for example, prior exam marks strongly correlate with internal assessment scores and assignment completion). Linear models suffer from variance inflation under collinearity, whereas Random Forest avoids this by randomly subsampling features at each split (`max_features="sqrt"`).
2. **Non-Linear Relationships:** Educational indicators rarely exhibit purely linear effects. A drop in attendance below 65% causes a disproportionate decline in grades compared to a drop from 95% to 90%. Decision-tree ensembles capture non-linear thresholds naturally without manual polynomial engineering.
3. **Low Overfitting (Ensemble Bagging):** A single Decision Tree has high variance and easily memorizes training noise. Random Forest averages predictions across 70 decorrelated trees trained on bootstrap samples, reducing variance according to the Law of Large Numbers without increasing bias.
4. **Native Feature Importance:** It provides built-in feature importance calculations (Gini impurity decrease / variance reduction), allowing explainable AI diagnostics for students and teachers.

### Q4: Explain the difference between the Regressor and Classifier in your system.
**Answer:**  
We implemented a dual-model architecture:
- **Random Forest Regressor:** Predicts continuous expected marks ($Y \in [0.0, 100.0]$). It splits nodes to minimize Mean Squared Error (MSE / variance reduction).
- **Random Forest Classifier:** Classifies students into one of four discrete performance tiers (`Needs Improvement`, `Average`, `Good`, `Excellent`). It splits nodes to minimize Gini Impurity:
  $$Gini = 1 - \sum_{i=1}^{C} p_i^2$$
  where $p_i$ is the probability of class $i$.

### Q5: What evaluation metrics did you use, and what do your actual test results mean?
**Answer:**  
The model was tested on an unseen 20% holdout test set (240 samples):

| Metric | Measured Value | Practical Academic Meaning |
| :--- | :--- | :--- |
| **Mean Absolute Error (MAE)** | `2.45` points | On average, the model's mark predictions are within $\pm 2.45\%$ of the student's actual performance. |
| **Root Mean Squared Error (RMSE)** | `3.00` points | Standard deviation of prediction residuals; penalizes large outlier errors heavily. |
| **$R^2$ Score** | `0.9646` | Over $96.4\%$ of the variance in student examination marks is successfully explained by our behavioral and academic features. |
| **Classification Accuracy** | `78.33%` | The model assigns the student to the correct exact tier out of 4 classes in nearly 8 out of 10 cases. |
| **Weighted F1-Score** | `75.97%` | Harmonic mean of precision and recall, balancing false positives and false negatives across imbalanced performance groups. |

---

## 3. Database & System Architecture

### Q6: Why did you use local SQLite instead of cloud databases like Firebase or Supabase?
**Answer:**  
1. **Data Sovereignty & Offline Execution:** Student academic records are sensitive institutional assets. SQLite stores everything locally inside a single relational file (`student_performance.db`), requiring no third-party cloud hosting, network egress, or external API credentials.
2. **ACID Compliance & Foreign Key Integrity:** SQLite supports full ACID (Atomicity, Consistency, Isolation, Durability) transactions and enforces cascading foreign key constraints (`ON DELETE CASCADE`), ensuring that deleting a student cleanly removes associated prediction logs without orphaned records.
3. **Portability:** The entire project directory can be zipped, moved to any computer, and executed immediately without setting up database servers or connection strings.

### Q7: Describe your SQLite database schema.
**Answer:**  
The database contains two relational tables:
- **`students` table:** Stores demographic and behavioral attributes (ID, Full Name, Age, Gender, Semester, Attendance %, Previous Marks, Study Hours, Assignment Completion %, Internal Marks, Extracurricular, Registration Date).
- **`predictions` table:** Stores historical evaluation runs (ID, Foreign Key `student_id`, Predicted Marks, Performance Level, Risk Level, Prediction Timestamp, Factors Summary).

---

## 4. Feature Engineering & Collinearity

### Q8: What is "Inter-Grade Collinearity" and how did you visualize it?
**Answer:**  
Inter-grade collinearity is the high statistical correlation between different grade types—for example, students who score high in internal assessments generally score high in previous exams ($r \approx 0.81$). We visualized this using an **Inter-Grade Collinearity Heatmap** displaying Pearson correlation coefficients ($r \in [-1, 1]$) in `pages/6_Reports_Analytics.py`. 

### Q9: What are the top three most influential factors determining academic performance?
**Answer:**  
Based on our Random Forest feature importance analysis:
1. **Previous Examination Marks (~26.5%):** Prior mastery of core curriculum is the strongest single predictor.
2. **Internal Assessment Marks (~25.4%):** Coursework tests demonstrate recent conceptual retention.
3. **Assignment Completion (~16.0%):** Regular homework reflects continuous effort and practice.
4. **Attendance Rate (~15.5%):** Classroom presence ensures exposure to faculty lectures.
5. **Study Hours (~12.3%):** Independent self-study solidifies learning.

---

## 5. Quick Reference: Project Architecture Diagram

```
           [ Student Input / Form ]
                      │
                      ▼
            [ Validation Layer ] ──> (Rejects invalid bounds)
                      │
                      ▼
         [ Feature Preprocessing ] ──> (Normalization & Encoding)
                      │
                      ▼
         [ Random Forest Model ]
            ├── Regressor: Expected Marks (e.g., 84.5%)
            └── Classifier: Performance Tier (e.g., Excellent)
                      │
                      ▼
       [ Explainable AI Diagnosis ] ──> (Generates strengths & risks)
                      │
                      ▼
       [ Local SQLite Persistence ] ──> (student_performance.db)
                      │
                      ▼
     [ Streamlit B&W Interface ] ──> (Dashboard, Reports, DB Viewer)
```

