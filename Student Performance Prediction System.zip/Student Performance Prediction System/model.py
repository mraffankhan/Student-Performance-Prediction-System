"""
model.py - Machine Learning Model Pipeline
Student Performance Prediction System

Implements Scikit-learn / NumPy Random Forest Regressor & Classifier, complete training workflow,
actual evaluation metrics (MAE, RMSE, R², Accuracy, Precision, Recall, F1, Confusion Matrix),
feature importance analysis, and prediction generation with academic explanations.
"""

import os
import pickle
import numpy as np
from datetime import datetime
from typing import Dict, Any, Tuple, List, Optional

import compat_pandas as pd
import preprocessing
import data_generator
import ml_engine

MODEL_DIR = os.path.join(os.path.dirname(os.path.abspath(__file__)), "models")
MODEL_FILE = os.path.join(MODEL_DIR, "random_forest_model.pkl")


def train_model() -> Dict[str, Any]:
    """
    Executes complete Machine Learning training workflow:
    1. Loads dataset
    2. Cleans missing and invalid values
    3. Performs feature selection and categorical encoding
    4. Splits into Train and Test sets (80/20)
    5. Trains Random Forest Regressor and Random Forest Classifier
    6. Computes actual evaluation metrics (MAE, RMSE, R², Accuracy, F1, Confusion Matrix)
    7. Saves trained artifact to models/random_forest_model.pkl
    """
    os.makedirs(MODEL_DIR, exist_ok=True)
    
    # 1. Load dataset
    csv_path = data_generator.ensure_dataset_exists()
    df = pd.read_csv(csv_path)

    # 2. Data Cleaning
    df = df.dropna(subset=preprocessing.ALL_FEATURE_COLUMNS + ["expected_marks", "performance_level"])
    
    # Ensure numeric columns are strictly numeric
    for col in preprocessing.NUMERIC_FEATURES:
        df[col] = pd.to_numeric(df[col], errors="coerce")
    df = df.dropna(subset=preprocessing.NUMERIC_FEATURES)

    # 3. Fit Transformer & Encode Data
    transformer = ml_engine.FeatureTransformer(
        numeric_cols=preprocessing.NUMERIC_FEATURES,
        categorical_cols=preprocessing.CATEGORICAL_FEATURES
    )
    X_all = transformer.fit_transform(df)
    y_reg_all = np.array([float(x) for x in df["expected_marks"]], dtype=float)
    y_clf_all = np.array([str(x) for x in df["performance_level"]])

    # 4. Train / Test Split (80% Train, 20% Test)
    n_samples = len(X_all)
    indices = np.arange(n_samples)
    rng = np.random.RandomState(42)
    rng.shuffle(indices)

    split_idx = int(0.80 * n_samples)
    train_idx = indices[:split_idx]
    test_idx = indices[split_idx:]

    X_train, X_test = X_all[train_idx], X_all[test_idx]
    y_reg_train, y_reg_test = y_reg_all[train_idx], y_reg_all[test_idx]
    y_clf_train, y_clf_test = y_clf_all[train_idx], y_clf_all[test_idx]

    # 5. Train Random Forest Regressor
    rf_reg = ml_engine.RandomForestRegressor(
        n_estimators=70,
        max_depth=10,
        min_samples_split=4,
        max_features="sqrt",
        random_state=42
    )
    rf_reg.fit(X_train, y_reg_train)

    # 6. Train Random Forest Classifier
    rf_clf = ml_engine.RandomForestClassifier(
        n_estimators=70,
        max_depth=8,
        min_samples_split=4,
        max_features="sqrt",
        random_state=42
    )
    rf_clf.fit(X_train, y_clf_train)

    # 7. Evaluate Actual Metrics on Unseen Test Set
    # Regression metrics
    y_reg_pred = rf_reg.predict(X_test)
    mae = ml_engine.mean_absolute_error(y_reg_test, y_reg_pred)
    rmse = ml_engine.root_mean_squared_error(y_reg_test, y_reg_pred)
    r2 = ml_engine.r2_score(y_reg_test, y_reg_pred)

    # Classification metrics
    y_clf_pred = rf_clf.predict(X_test)
    classes = ["Needs Improvement", "Average", "Good", "Excellent"]
    acc = ml_engine.accuracy_score(y_clf_test, y_clf_pred)
    prec, rec, f1, cm = ml_engine.classification_report_metrics(y_clf_test, y_clf_pred, classes)

    # 8. Feature Importances
    all_feature_names = transformer.feature_names_out_
    raw_importances = rf_reg.feature_importances_
    
    # Aggregate importance by parent input feature
    base_feature_imp = {}
    for feat_name, imp in zip(all_feature_names, raw_importances):
        matched = feat_name
        for b in preprocessing.ALL_FEATURE_COLUMNS:
            if feat_name.startswith(b):
                matched = b
                break
        base_feature_imp[matched] = base_feature_imp.get(matched, 0.0) + float(imp)

    base_imp_list = [
        {"feature": k.replace("_", " ").title(), "raw_feature": k, "importance": round(v, 4)}
        for k, v in base_feature_imp.items()
    ]
    base_imp_list.sort(key=lambda x: x["importance"], reverse=True)

    model_bundle = {
        "regressor": rf_reg,
        "classifier": rf_clf,
        "transformer": transformer,
        "metrics": {
            "regression": {
                "mae": round(mae, 3),
                "rmse": round(rmse, 3),
                "r2": round(r2, 4)
            },
            "classification": {
                "accuracy": round(acc, 4),
                "precision": round(prec, 4),
                "recall": round(rec, 4),
                "f1_score": round(f1, 4),
                "classes": classes,
                "confusion_matrix": cm.tolist()
            }
        },
        "feature_importances": base_imp_list,
        "trained_at": datetime.now().strftime("%Y-%m-%d %H:%M:%S"),
        "training_samples": len(X_train),
        "test_samples": len(X_test)
    }

    with open(MODEL_FILE, "wb") as f:
        pickle.dump(model_bundle, f)

    return model_bundle


def load_model() -> Optional[Dict[str, Any]]:
    """Loads the model bundle from disk if it exists."""
    if os.path.exists(MODEL_FILE):
        try:
            with open(MODEL_FILE, "rb") as f:
                return pickle.load(f)
        except Exception:
            return None
    return None


def ensure_model_trained() -> Dict[str, Any]:
    """Ensures a model is loaded or trained."""
    bundle = load_model()
    if bundle is None:
        bundle = train_model()
    return bundle


def predict_student_performance(student_data: Dict[str, Any]) -> Dict[str, Any]:
    """
    Generates academic performance prediction for student data dictionary.
    Returns predicted marks, performance tier, risk level, and academic explanation.
    """
    bundle = ensure_model_trained()
    rf_reg = bundle["regressor"]
    transformer = bundle["transformer"]

    # Build input row
    row = {
        "attendance": float(student_data.get("attendance", 75.0)),
        "previous_marks": float(student_data.get("previous_marks", 70.0)),
        "study_hours": float(student_data.get("study_hours", 4.0)),
        "assignment_completion": float(student_data.get("assignment_completion", 80.0)),
        "internal_marks": float(student_data.get("internal_marks", 70.0)),
        "age": int(student_data.get("age", 20)),
        "semester": str(student_data.get("semester", "Semester 1")),
        "gender": str(student_data.get("gender", "Unspecified")),
        "extracurricular": str(student_data.get("extracurricular", "No"))
    }
    input_df = pd.DataFrame([row])
    X_input = transformer.transform(input_df)

    # Predict marks with Random Forest Regressor
    raw_pred = rf_reg.predict(X_input)[0]
    predicted_marks = round(float(np.clip(raw_pred, 0.0, 100.0)), 1)

    # Determine performance tier & risk level
    perf_level = preprocessing.categorize_performance(predicted_marks)
    risk_level = preprocessing.determine_risk_level(
        predicted_marks=predicted_marks,
        attendance=row["attendance"],
        previous_marks=row["previous_marks"]
    )

    # Key factors impact breakdown
    factors = []
    strengths = []
    concerns = []

    # Previous marks
    if row["previous_marks"] >= 75:
        strengths.append(f"Strong prior academic foundation ({row['previous_marks']}%)")
    elif row["previous_marks"] < 50:
        concerns.append(f"Low prior exam scores ({row['previous_marks']}%)")
    factors.append({"factor": "Previous Marks", "value": f"{row['previous_marks']}%", "status": "Positive" if row["previous_marks"] >= 65 else "Attention Needed"})

    # Attendance
    if row["attendance"] >= 80:
        strengths.append(f"Consistent lecture attendance ({row['attendance']}%)")
    elif row["attendance"] < 65:
        concerns.append(f"Critical attendance deficit ({row['attendance']}%)")
    factors.append({"factor": "Attendance", "value": f"{row['attendance']}%", "status": "Positive" if row["attendance"] >= 75 else "Attention Needed"})

    # Study hours
    if row["study_hours"] >= 5.0:
        strengths.append(f"Dedicated daily study routine ({row['study_hours']} hrs/day)")
    elif row["study_hours"] < 2.5:
        concerns.append(f"Sub-optimal daily study hours ({row['study_hours']} hrs/day)")
    factors.append({"factor": "Study Hours", "value": f"{row['study_hours']} hrs/day", "status": "Positive" if row["study_hours"] >= 3.5 else "Attention Needed"})

    # Internal marks
    if row["internal_marks"] >= 75:
        strengths.append(f"Solid internal assessment ({row['internal_marks']}%)")
    elif row["internal_marks"] < 50:
        concerns.append(f"Weak internal assessment ({row['internal_marks']}%)")
    factors.append({"factor": "Internal Assessment", "value": f"{row['internal_marks']}%", "status": "Positive" if row["internal_marks"] >= 60 else "Attention Needed"})

    # Assignment completion
    if row["assignment_completion"] >= 85:
        strengths.append(f"High assignment completion rate ({row['assignment_completion']}%)")
    elif row["assignment_completion"] < 60:
        concerns.append(f"Incomplete assignment coursework ({row['assignment_completion']}%)")
    factors.append({"factor": "Assignment Completion", "value": f"{row['assignment_completion']}%", "status": "Positive" if row["assignment_completion"] >= 70 else "Attention Needed"})

    # Synthesis & guidance
    parts = []
    if strengths:
        parts.append(f"Key academic drivers: {', '.join(strengths)}.")
    if concerns:
        parts.append(f"Attention areas: {', '.join(concerns)}.")

    if risk_level == "High":
        parts.append("Recommendation: Immediate faculty mentoring, remedial support, and attendance counseling.")
    elif risk_level == "Medium":
        parts.append("Recommendation: Focused practice on weak subjects and increasing weekly study hours.")
    else:
        parts.append("Recommendation: Maintain study discipline; encourage peer tutoring or advanced honors projects.")

    explanation = " ".join(parts)

    return {
        "predicted_marks": predicted_marks,
        "performance_level": perf_level,
        "risk_level": risk_level,
        "explanation": explanation,
        "factors": factors,
        "strengths": strengths,
        "concerns": concerns,
        "feature_importances": bundle.get("feature_importances", [])
    }
