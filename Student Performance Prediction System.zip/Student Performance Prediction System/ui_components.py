"""
ui_components.py - Shared UI Components & Monochrome Styling
Student Performance Prediction System

Provides unified styling, header, navigation, and monochrome Plotly chart builders.
"""

import os
import streamlit as st
import plotly.express as px
import plotly.graph_objects as go
from typing import List, Dict, Any, Optional

STYLE_FILE = os.path.join(os.path.dirname(os.path.abspath(__file__)), "assets", "style.css")

# Monochrome Color Palette
COLOR_BLACK = "#000000"
COLOR_DARK_GRAY = "#2b2d42"
COLOR_MID_GRAY = "#6c757d"
COLOR_LIGHT_GRAY = "#adb5bd"
COLOR_VERY_LIGHT_GRAY = "#e9ecef"
COLOR_WHITE = "#ffffff"

MONO_CHART_COLORS = ["#111111", "#444444", "#777777", "#aaaaaa", "#cccccc"]


def apply_custom_theme():
    """Applies the custom Black & White CSS styling to the current Streamlit page."""
    if os.path.exists(STYLE_FILE):
        with open(STYLE_FILE, "r", encoding="utf-8") as f:
            css = f.read()
            st.markdown(f"<style>{css}</style>", unsafe_allow_html=True)


def render_sidebar():
    """Renders the standard Black & White sidebar with project info and system status."""
    with st.sidebar:
        st.markdown(
            """
            <div style="padding: 0.5rem 0 1rem 0;">
                <h2 style="margin: 0; font-size: 1.25rem; font-weight: 800; letter-spacing: -0.02em;">ACADEMIC AI LAB</h2>
                <div style="font-size: 0.75rem; letter-spacing: 0.08em; text-transform: uppercase; color: #a1a1aa;">
                    Student Performance System
                </div>
            </div>
            """,
            unsafe_allow_html=True
        )

        st.markdown("---")

        # System Status Indicators
        import database
        import model
        db_info = database.get_database_info()
        trained_bundle = model.load_model()
        model_status = "Trained & Ready" if trained_bundle else "Pending Training"
        db_status = "Connected (SQLite)" if os.path.exists(database.DB_PATH) else "Not Found"

        st.markdown(
            f"""
            <div style="background: #18181b; padding: 0.85rem; border-radius: 6px; border: 1px solid #27272a; margin-bottom: 1rem;">
                <div style="font-size: 0.7rem; font-weight: 700; color: #a1a1aa; text-transform: uppercase; margin-bottom: 0.4rem;">System Status</div>
                <div style="display: flex; justify-content: space-between; font-size: 0.78rem; margin-bottom: 0.25rem;">
                    <span style="color: #71717a;">Database:</span>
                    <span style="color: #fafafa; font-weight: 600;">{db_status}</span>
                </div>
                <div style="display: flex; justify-content: space-between; font-size: 0.78rem; margin-bottom: 0.25rem;">
                    <span style="color: #71717a;">ML Engine:</span>
                    <span style="color: #fafafa; font-weight: 600;">{model_status}</span>
                </div>
                <div style="display: flex; justify-content: space-between; font-size: 0.78rem;">
                    <span style="color: #71717a;">Students:</span>
                    <span style="color: #fafafa; font-weight: 600;">{db_info['table_counts'].get('students', 0)}</span>
                </div>
            </div>
            """,
            unsafe_allow_html=True
        )

        st.markdown("---")
        st.markdown(
            """
            <div style="font-size: 0.72rem; color: #71717a; line-height: 1.4;">
                <strong>Project:</strong> BCA Final Year / Internship AIML<br>
                <strong>Algorithm:</strong> Random Forest<br>
                <strong>Storage:</strong> Local SQLite DB<br>
                <strong>Theme:</strong> Monochrome Minimalist
            </div>
            """,
            unsafe_allow_html=True
        )


def render_page_header(title: str, subtitle: Optional[str] = None):
    """Renders a clean, academic monochrome page header."""
    apply_custom_theme()
    st.markdown(
        f"""
        <div style="margin-bottom: 1.75rem; border-bottom: 1px solid #e2e8f0; padding-bottom: 0.85rem;">
            <h1 style="font-size: 1.95rem; font-weight: 800; color: #000000; margin: 0; letter-spacing: -0.03em;">{title}</h1>
            {f'<p style="font-size: 0.95rem; color: #64748b; margin-top: 0.35rem; margin-bottom: 0;">{subtitle}</p>' if subtitle else ''}
        </div>
        """,
        unsafe_allow_html=True
    )


def metric_card(title: str, value: Any, subtitle: Optional[str] = None):
    """Renders a minimalist KPI card."""
    return f"""
    <div class="bw-card">
        <div class="bw-card-header">{title}</div>
        <div class="bw-card-value">{value}</div>
        {f'<div class="bw-card-sub">{subtitle}</div>' if subtitle else ''}
    </div>
    """


def get_risk_badge_html(risk_level: str) -> str:
    """Returns HTML for a monochrome risk badge."""
    level = str(risk_level).capitalize()
    if level == "High":
        return f'<span class="badge-high">HIGH RISK</span>'
    elif level == "Medium":
        return f'<span class="badge-medium">MEDIUM RISK</span>'
    else:
        return f'<span class="badge-low">LOW RISK</span>'


def get_performance_badge_html(perf_level: str) -> str:
    """Returns HTML for performance tier badge."""
    level = str(perf_level)
    return f'<span style="border: 1px solid #000000; padding: 0.2rem 0.5rem; border-radius: 4px; font-weight: 700; font-size: 0.75rem; background: #ffffff; color: #000000;">{level.upper()}</span>'


def render_table(df_or_records, max_rows: int = 100):
    """
    Renders an elegant, responsive HTML table in pure monochrome design.
    Bypasses pyarrow / pandas C-extension dependencies completely to prevent
    Windows Smart App Control DLL load errors.
    """
    import html

    if hasattr(df_or_records, "to_dict"):
        records = df_or_records.to_dict(orient="records")
        cols = list(df_or_records.columns)
    elif isinstance(df_or_records, list):
        records = df_or_records
        cols = list(records[0].keys()) if records else []
    else:
        records = []
        cols = []

    if not records or not cols:
        st.info("No records to display.")
        return

    # Bound rows for display performance
    visible_records = records[:max_rows]

    table_html = """
    <div style="overflow-x: auto; margin: 1rem 0; border: 1px solid #e2e8f0; border-radius: 6px; box-shadow: 0 1px 2px rgba(0,0,0,0.03);">
        <table style="width: 100%; border-collapse: collapse; font-family: 'Inter', -apple-system, sans-serif; text-align: left;">
            <thead>
                <tr style="background-color: #000000; color: #ffffff;">
    """
    for c in cols:
        table_html += f'<th style="padding: 10px 14px; font-size: 0.78rem; font-weight: 700; text-transform: uppercase; letter-spacing: 0.05em; border-bottom: 2px solid #000000; border-right: 1px solid #222222; white-space: nowrap;">{html.escape(str(c))}</th>'
    table_html += """
                </tr>
            </thead>
            <tbody>
    """
    for idx, row in enumerate(visible_records):
        bg = "#ffffff" if idx % 2 == 0 else "#f8fafc"
        table_html += f'<tr style="background-color: {bg}; border-bottom: 1px solid #e2e8f0; transition: background-color 0.1s ease;">'
        for c in cols:
            val = str(row.get(c, ""))
            if val is None or val == "None":
                val = ""
            table_html += f'<td style="padding: 9px 14px; font-size: 0.83rem; color: #0f172a; border-right: 1px solid #f1f5f9; white-space: nowrap;">{html.escape(val)}</td>'
        table_html += '</tr>'

    table_html += """
            </tbody>
        </table>
    </div>
    """
    if len(records) > max_rows:
        table_html += f'<div style="font-size: 0.75rem; color: #64748b; margin-top: -0.5rem; margin-bottom: 0.5rem;">Showing first {max_rows} of {len(records)} records.</div>'

    st.markdown(table_html, unsafe_allow_html=True)


def create_monochrome_bar_chart(df, x_col: str, y_col: str, title: str, x_label: str = "", y_label: str = "") -> go.Figure:
    """Creates a clean monochrome Plotly bar chart."""
    fig = go.Figure(data=[
        go.Bar(
            x=df[x_col],
            y=df[y_col],
            marker=dict(
                color="#111111",
                line=dict(color="#000000", width=1)
            ),
            hoverinfo="x+y"
        )
    ])
    fig.update_layout(
        title=dict(text=title, font=dict(family="Inter", size=15, color="#000000")),
        xaxis=dict(title=x_label, showgrid=False, linecolor="#000000", tickfont=dict(family="Inter", color="#333333")),
        yaxis=dict(title=y_label, showgrid=True, gridcolor="#f0f0f0", linecolor="#000000", tickfont=dict(family="Inter", color="#333333")),
        plot_bgcolor="#ffffff",
        paper_bgcolor="#ffffff",
        margin=dict(l=40, r=20, t=50, b=40),
        height=340
    )
    return fig


def create_monochrome_histogram(data: List[float], title: str, x_label: str = "", nbins: int = 15) -> go.Figure:
    """Creates a clean monochrome histogram."""
    fig = go.Figure(data=[
        go.Histogram(
            x=data,
            nbinsx=nbins,
            marker=dict(
                color="#333333",
                line=dict(color="#000000", width=1)
            )
        )
    ])
    fig.update_layout(
        title=dict(text=title, font=dict(family="Inter", size=15, color="#000000")),
        xaxis=dict(title=x_label, showgrid=False, linecolor="#000000", tickfont=dict(family="Inter", color="#333333")),
        yaxis=dict(title="Student Count", showgrid=True, gridcolor="#f0f0f0", linecolor="#000000", tickfont=dict(family="Inter", color="#333333")),
        plot_bgcolor="#ffffff",
        paper_bgcolor="#ffffff",
        margin=dict(l=40, r=20, t=50, b=40),
        height=340
    )
    return fig


def create_monochrome_donut_chart(labels: List[str], values: List[int], title: str) -> go.Figure:
    """Creates a clean monochrome donut chart for category distributions."""
    fig = go.Figure(data=[
        go.Pie(
            labels=labels,
            values=values,
            hole=0.55,
            marker=dict(colors=MONO_CHART_COLORS[:len(labels)], line=dict(color="#ffffff", width=2)),
            textinfo="label+percent"
        )
    ])
    fig.update_layout(
        title=dict(text=title, font=dict(family="Inter", size=15, color="#000000")),
        showlegend=True,
        legend=dict(orientation="h", yanchor="bottom", y=-0.2, xanchor="center", x=0.5),
        plot_bgcolor="#ffffff",
        paper_bgcolor="#ffffff",
        margin=dict(l=20, r=20, t=40, b=40),
        height=340
    )
    return fig

