"""
test_system.py - Automated Unit & Integration Test Suite
Student Performance Prediction System

Run directly with:
    python test_system.py
"""

import sys
import unittest
import database
import model
import preprocessing
import data_generator


class TestStudentPerformanceSystem(unittest.TestCase):

    @classmethod
    def setUpClass(cls):
        database.init_db()
        data_generator.ensure_dataset_exists()
        cls.bundle = model.ensure_model_trained()

    def test_01_database_tables_exist(self):
        info = database.get_database_info()
        self.assertIn("students", info["tables"])
        self.assertIn("predictions", info["tables"])

    def test_02_model_metrics_valid(self):
        metrics = self.bundle.get("metrics", {})
        reg = metrics.get("regression", {})
        clf = metrics.get("classification", {})

        # R2 should be positive and high
        self.assertGreater(reg.get("r2", 0), 0.85)
        self.assertLess(reg.get("mae", 100), 5.0)
        self.assertGreater(clf.get("accuracy", 0), 0.70)

    def test_03_form_validation(self):
        # Invalid age
        v, err = preprocessing.validate_student_data({
            "student_name": "Test", "age": 10, "attendance": 80,
            "previous_marks": 80, "study_hours": 4, "assignment_completion": 80,
            "internal_marks": 80, "semester": "Semester 1"
        })
        self.assertFalse(v)
        self.assertIn("Age must be", err)

        # Invalid attendance
        v, err = preprocessing.validate_student_data({
            "student_name": "Test", "age": 20, "attendance": 105,
            "previous_marks": 80, "study_hours": 4, "assignment_completion": 80,
            "internal_marks": 80, "semester": "Semester 1"
        })
        self.assertFalse(v)
        self.assertIn("Attendance percentage", err)

    def test_04_student_lifecycle(self):
        payload = {
            "student_name": "Automated Test Candidate",
            "age": 21,
            "gender": "Female",
            "semester": "Semester 3",
            "attendance": 92.0,
            "previous_marks": 85.0,
            "study_hours": 5.0,
            "assignment_completion": 94.0,
            "internal_marks": 88.0,
            "extracurricular": "Yes"
        }
        stu_id = database.add_student(payload)
        self.assertTrue(stu_id.startswith("STU-"))

        # Verify retrieval
        stu = database.get_student_by_id(stu_id)
        self.assertIsNotNone(stu)
        self.assertEqual(stu["student_name"], "Automated Test Candidate")

        # Test prediction
        pred = model.predict_student_performance(stu)
        self.assertGreaterEqual(pred["predicted_marks"], 0.0)
        self.assertLessEqual(pred["predicted_marks"], 100.0)
        self.assertEqual(pred["performance_level"], "Excellent")
        self.assertEqual(pred["risk_level"], "Low")

        # Test prediction log
        pred_id = database.add_prediction({
            "student_id": stu_id,
            "student_name": stu["student_name"],
            "predicted_marks": pred["predicted_marks"],
            "performance_level": pred["performance_level"],
            "risk_level": pred["risk_level"],
            "factors_summary": pred["explanation"]
        })
        self.assertGreater(pred_id, 0)

        # Clean up
        deleted = database.delete_student(stu_id)
        self.assertTrue(deleted)
        self.assertIsNone(database.get_student_by_id(stu_id))

    def test_05_database_viewer_introspection(self):
        schema = database.get_table_schema("students")
        self.assertGreaterEqual(len(schema), 12)

        ok, df = database.execute_raw_query("SELECT COUNT(*) as count FROM students;")
        self.assertTrue(ok)
        self.assertGreaterEqual(df["count"][0], 0)

    def test_06_dashboard_kpis(self):
        metrics = database.get_dashboard_metrics()
        self.assertIn("total_students", metrics)
        self.assertIn("total_predictions", metrics)
        self.assertIn("high_risk_count", metrics)
        self.assertIn("avg_predicted_marks", metrics)


if __name__ == "__main__":
    print("=" * 60)
    print("STUDENT PERFORMANCE PREDICTION SYSTEM - TEST SUITE")
    print("=" * 60)
    runner = unittest.TextTestRunner(verbosity=2)
    suite = unittest.TestLoader().loadTestsFromTestCase(TestStudentPerformanceSystem)
    result = runner.run(suite)
    sys.exit(0 if result.wasSuccessful() else 1)

